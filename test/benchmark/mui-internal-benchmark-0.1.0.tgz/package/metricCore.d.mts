import type { MetricConfig, MetricKind } from "./types.mjs";
export interface MetricRecordOptions {
  /** Sub-series label. Recorded under `${name}#${id}` in the report; omit for the base series. */
  id?: string;
}
/** The name a sub-series is reported under: `name#id`, or `name` for the base series. */
export declare function seriesName(name: string, id: string | undefined): string;
/** The metric a series belongs to: `name#id` without its `#id`. */
export declare function baseMetricName(series: string): string;
/** Where recorded values go: the runtime a benchmark runs under installs one. */
export type MetricRecorder = (metric: Metric, value: number, options: MetricRecordOptions | undefined) => void;
export declare function setMetricRecorder(next: MetricRecorder): void;
/**
 * Base class for custom benchmark metrics. Use `ScalarMetric` or `DiscreteMetric`.
 *
 * A single instance can be declared at module scope and reused across tests and loop iterations,
 * inside or outside React; the active runtime decides which test or sample a value belongs to.
 */
export declare abstract class Metric {
  abstract readonly kind: MetricKind;
  readonly name: string;
  readonly config: MetricConfig;
  constructor(config: MetricConfig | string);
  /**
   * Records a single measured value. Pass `options.id` to split into a labeled sub-series.
   */
  record(value: number, options?: MetricRecordOptions): void;
}