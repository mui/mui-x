import react from '@vitejs/plugin-react';
import { playwright } from '@vitest/browser-playwright';
import { BENCHMARK_LAUNCH_ARGS, BENCHMARK_VIEWPORT, withLaunchArgs } from "./launchArgs.mjs";
// Default viewport for all benchmark runs (measurement and profiling alike) — a desktop size is
// more representative for component benchmarks than Vitest's phone-sized 414x896 browser default.

// Explicit viewport from the `viewport` option or the `BENCHMARK_VIEWPORT` env var
// (`<width>x<height>`); undefined when neither is set, so the caller can apply the default.
function resolveViewport(option) {
  if (option) {
    return option;
  }
  const env = process.env.BENCHMARK_VIEWPORT;
  const match = env ? env.split('x') : null;
  if (match && match.length === 2) {
    return {
      width: Number(match[0]),
      height: Number(match[1])
    };
  }
  return undefined;
}
export function createBenchmarkVitestConfig(options) {
  // Benchmarks have to measure production React, which is why the config below sets NODE_ENV to
  // "production" for the code running in the browser. That alone isn't enough: Vite picks which
  // JSX runtime to compile against by reading NODE_ENV from the Node process, where Vitest has set
  // it to "test". Benchmarks then get development JSX calling into a production React build, which
  // has no `jsxDEV` function, and every benchmark crashes on its first render with
  // "_jsxDEV is not a function".
  //
  // Setting NODE_ENV here, while this config file is still being evaluated, means Vite reads
  // "production" as well and the two agree. Vitest considers this the intended way to run tests
  // against production React: https://github.com/vitest-dev/vitest/issues/11265
  // eslint-disable-next-line mui/consistent-production-guard -- an assignment, not a guard
  process.env.NODE_ENV = 'production';
  const {
    outputPath,
    baselinePath,
    launchArgs = []
  } = options ?? {};
  const profile = options?.profile ?? process.env.BENCHMARK_PROFILE === 'true';
  const viewport = resolveViewport(options?.viewport) ?? BENCHMARK_VIEWPORT;

  // Profiling adds DevTools on top of the shared args, plus a window sized to match the viewport —
  // Vitest's `viewport` only sizes the iframe, so otherwise it's cropped/scrolled in the headed
  // window instead of filling it. (Measurement is headless, so it has no window to size.)
  const profileArgs = [...BENCHMARK_LAUNCH_ARGS, '--auto-open-devtools-for-tabs', `--window-size=${viewport.width},${viewport.height}`];
  return {
    plugins: [react()],
    define: {
      'process.env.NODE_ENV': '"production"',
      'process.env.BENCHMARK_PROFILE': JSON.stringify(profile ? 'true' : '')
    },
    resolve: {
      dedupe: ['react', 'react-dom'],
      alias: [{
        find: 'react-dom/client',
        replacement: 'react-dom/profiling'
      }]
    },
    test: {
      browser: {
        enabled: true,
        headless: !profile,
        // Profiling renders into a clean page: hide Vitest's browser runner UI
        // so the orchestrator chrome doesn't clutter what you're profiling.
        ui: profile ? false : undefined,
        // Same viewport for both modes (BENCHMARK_VIEWPORT unless overridden).
        viewport,
        screenshotFailures: false,
        instances: [{
          browser: 'chromium',
          // Profiling sessions are driven by hand, so give them effectively
          // unlimited time instead of the measurement timeout.
          testTimeout: profile ? 0 : 120_000
        }],
        provider: playwright({
          launchOptions: {
            args: withLaunchArgs(launchArgs, profile ? profileArgs : BENCHMARK_LAUNCH_ARGS)
          }
        })
      },
      fileParallelism: false,
      // Profiling sessions don't measure anything, so skip the results reporter.
      reporters: profile ? ['default'] : ['default', ['@mui/internal-benchmark/reporter', {
        outputPath,
        baselinePath
      }]],
      include: ['**/*.bench.tsx']
    }
  };
}