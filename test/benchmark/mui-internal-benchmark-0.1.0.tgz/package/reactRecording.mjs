/**
 * Creates the per-iteration switch that turns the harness's React render/paint recording on and
 * off. The interaction callback drives it via `pauseReactRecording`/`resumeReactRecording`; the
 * strict state machine (each throws when called in the wrong state) catches unbalanced pairs early.
 *
 * It also tracks whether each *active* window captured at least one render, so the harness can flag
 * a window that was recording but measured nothing — while leaving fully-paused (metric-only)
 * benchmarks alone.
 */
export function createReactRecordingControls(initiallyActive) {
  let active = initiallyActive;
  let currentWindowHasRender = false;
  let emptyActiveWindow = false;
  // Transitions in chronological order. The implicit state before the first toggle is
  // `initiallyActive`; `activeSince` replays this to attribute a paint to its window.
  const transitions = [];

  // Flag the window being closed if it was recording yet captured nothing.
  function closeWindowIfActive() {
    if (active && !currentWindowHasRender) {
      emptyActiveWindow = true;
    }
  }
  return {
    get active() {
      return active;
    },
    get hadEmptyActiveWindow() {
      return emptyActiveWindow;
    },
    activeSince(time) {
      let since = initiallyActive ? -Infinity : null;
      for (const transition of transitions) {
        if (transition.time > time) {
          break;
        }
        since = transition.active ? transition.time : null;
      }
      return since;
    },
    markRendered() {
      currentWindowHasRender = true;
    },
    finalizeWindow() {
      closeWindowIfActive();
    },
    pauseReactRecording() {
      // Stamp first — before the guard and bookkeeping — so the closing window ends as early as
      // possible and excludes pause's own overhead. In the throw path it is simply discarded.
      const now = performance.now();
      if (!active) {
        throw new Error('pauseReactRecording() called but React recording is already paused.');
      }
      closeWindowIfActive();
      active = false;
      transitions.push({
        time: now,
        active: false
      });
    },
    resumeReactRecording() {
      if (active) {
        throw new Error('resumeReactRecording() called but React recording is already active.');
      }
      active = true;
      currentWindowHasRender = false;
      // Stamp last — after the bookkeeping — so the new window starts as late as possible and
      // excludes resume's own overhead.
      const now = performance.now();
      transitions.push({
        time: now,
        active: true
      });
    }
  };
}