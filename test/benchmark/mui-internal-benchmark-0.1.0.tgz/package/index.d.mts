import type * as React from 'react';
import type { BenchmarkInteraction, BenchmarkOptions } from "./caseRuntime.mjs";
import "./Metric.mjs";
import "./taskMetaAugmentation.mjs";
export * from "./publicApi.mjs";
export type { BenchmarkOptions };
export declare function benchmark(name: string, renderFn: () => React.ReactElement, interactionOrOptions?: BenchmarkInteraction | BenchmarkOptions, maybeOptions?: BenchmarkOptions): void;