import { collectGarbage } from "../gc.mjs";
import { seriesName, setMetricRecorder } from "../metricCore.mjs";
import { getSampling } from "../sampling.mjs";

// The page runtime the `benchmark` CLI measures. `benchmark()` registers a case, and the runner calls
// `window.benchmarkPage.sample()` to run one iteration of it at a time. What a case measures is
// whatever it records through a `Metric`; every recorded value leaves the page as a
// `performance.measure` entry, so it also shows up in a DevTools trace.

/** What a case's `run` is handed on every iteration. */

/**
 * One iteration of a case. It records its results through `Metric`s — `ScalarMetric`,
 * `DiscreteMetric` — and must record at least one value.
 */

/** A registered case, as `benchmark()` returns it for `compare()` to group. */

/** Every case the file registered, by name, with the sampling and alarms it set. */
const cases = new Map();

/**
 * Registers a benchmark case. The runner calls `run` once per sample, in a page loaded afresh every
 * round and shared with the file's other cases, for as many rounds as `options` asks. A case on its own is measured across the builds; one
 * passed to `compare()` is measured against the other cases there instead, sampled as the
 * `compare()` asks, and never alarms.
 */
export function benchmark(name, run, options = {}) {
  if (cases.has(name)) {
    throw new Error(`Two benchmarks share the name "${name}". Benchmark names must be unique.`);
  }
  cases.set(name, {
    run,
    sampling: getSampling(options),
    alarms: options.alarms
  });
  return {
    name
  };
}

/** Each `compare()`, with its cases' names, the reference first. */
const comparisons = [];

/**
 * Compares cases with each other — one library's implementation against another's, say — on the
 * working tree's build, rather than each against its baseline. The first case is the reference.
 *
 * Every page load runs the whole file. Import what only one case needs inside that case, before the
 * part it times, to keep it out of the others' samples.
 */
export function compare(name, compared, sampling = {}) {
  if (comparisons.some(comparison => comparison.name === name)) {
    throw new Error(`Two comparisons share the name "${name}". Comparison names must be unique.`);
  }
  if (compared.length < 2) {
    throw new Error(`Comparison "${name}" needs at least two cases.`);
  }
  const ownSampling = getSampling(sampling);
  for (const benchCase of compared) {
    const own = cases.get(benchCase.name);
    if (own && (own.sampling.sampleSize !== undefined || own.sampling.timeout !== undefined)) {
      throw new Error(`"${benchCase.name}" sets its own sampling, but a compared case is sampled as its ` + `compare() asks: pass the options to compare("${name}", …) instead.`);
    }
    if (own?.alarms) {
      throw new Error(`"${benchCase.name}" sets its own alarms, but a compared case never alarms: its ` + `variants differ on purpose.`);
    }
    const owner = comparisons.find(comparison => comparison.cases.includes(benchCase.name));
    if (owner) {
      throw new Error(`"${benchCase.name}" is already compared in "${owner.name}".`);
    }
  }
  comparisons.push({
    name,
    cases: compared.map(benchCase => benchCase.name),
    sampling: ownSampling
  });
}

// Values recorded during a sample, summed per series: a metric recorded more than once in an
// iteration counts its total for that iteration. `null` outside a sample (module scope), where
// recorded values are dropped.
let sampleValues = null;

// Every metric recorded so far, by name, as the report describes it.
const metricDefinitions = new Map();
setMetricRecorder((metric, value, options) => {
  if (!metricDefinitions.has(metric.name)) {
    metricDefinitions.set(metric.name, {
      kind: metric.kind,
      format: metric.config.format,
      alarm: metric.config.alarm
    });
  }
  if (sampleValues) {
    const series = seriesName(metric.name, options?.id);
    sampleValues.set(series, (sampleValues.get(series) ?? 0) + value);
  }
});
/**
 * Puts a sample's spans on a "Benchmark" track of their own in a DevTools trace, through the
 * Performance panel's extensibility API; elsewhere, the `detail` is just data.
 */
function benchmarkTrackDetail(color) {
  return {
    devtools: {
      dataType: 'track-entry',
      track: 'Benchmark',
      color
    }
  };
}
const send = (method, params) => {
  if (!window.benchmarkCdp) {
    throw new Error('No CDP bridge: the runner must expose `benchmarkCdp` on this page.');
  }
  return window.benchmarkCdp(method, params);
};
const cdp = {
  send
};
async function sample(name) {
  const run = cases.get(name)?.run;
  if (!run) {
    throw new Error(`No benchmark named "${name}". Known: ${[...cases.keys()].join(', ')}`);
  }
  performance.clearMarks();
  performance.clearMeasures();
  const collectStart = performance.now();
  await collectGarbage();
  const values = new Map();
  sampleValues = values;
  const runStart = performance.now();
  try {
    await run({
      cdp
    });
  } finally {
    sampleValues = null;
    // The collection and the run as spans of a trace, written after the run so that only reading
    // the clock happens between the two.
    performance.measure('collect', {
      start: collectStart,
      end: runStart,
      detail: benchmarkTrackDetail('tertiary')
    });
    performance.measure('run', {
      start: runStart,
      end: performance.now(),
      detail: benchmarkTrackDetail('primary')
    });
  }
  if (values.size === 0) {
    throw new Error(`Benchmark "${name}" recorded no value. Record its results through a ScalarMetric or DiscreteMetric.`);
  }
  // Also left as `performance.measure` entries, so a sample shows up in a DevTools trace.
  const now = performance.now();
  for (const [series, value] of values) {
    performance.measure(series, {
      start: now,
      duration: 0,
      detail: {
        value
      }
    });
  }
  return Object.fromEntries(values);
}

/**
 * Called by the generated page entry after it has imported the benchmark file. The runner waits for
 * `window.benchmarkPage`.
 */
export function markPageReady() {
  window.benchmarkPage = {
    cases: [...cases].filter(([name]) => !comparisons.some(comparison => comparison.cases.includes(name))).map(([name, {
      sampling,
      alarms
    }]) => ({
      name,
      sampling,
      ...(alarms ? {
        alarms
      } : {})
    })),
    comparisons,
    metricDefinitions: () => Object.fromEntries(metricDefinitions),
    sample
  };
}