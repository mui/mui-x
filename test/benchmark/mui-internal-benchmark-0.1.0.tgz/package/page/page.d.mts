import type { BenchmarkCdp } from "../cdp.mjs";
import type { SamplingOptions } from "../sampling.mjs";
import type { MetricDefinition } from "../types.mjs";
import type { RunMetricAlarm } from "../runReport/schema.mjs";
/** What a case's `run` is handed on every iteration. */
export interface BenchmarkContext {
  /** The DevTools Protocol, for what the case sets up or reads from the browser itself. */
  cdp: BenchmarkCdp;
}
/**
 * One iteration of a case. It records its results through `Metric`s — `ScalarMetric`,
 * `DiscreteMetric` — and must record at least one value.
 */
export type BenchmarkRun = (context: BenchmarkContext) => Promise<void> | void;
/** A registered case, as `benchmark()` returns it for `compare()` to group. */
export interface BenchmarkCase {
  readonly name: string;
}
export interface BenchmarkCaseOptions extends SamplingOptions {
  /**
   * This benchmark's own alarms, by metric name, in place of the metric's: its fields override the
   * metric's alarm — a lower `error` band for a benchmark that matters more, a higher one for one
   * that matters less — and `false` means the metric never alarms here. A `name#id` sub-series
   * follows its base metric.
   */
  alarms?: Record<string, RunMetricAlarm | false>;
}
/**
 * Registers a benchmark case. The runner calls `run` once per sample, in a page loaded afresh every
 * round and shared with the file's other cases, for as many rounds as `options` asks. A case on its own is measured across the builds; one
 * passed to `compare()` is measured against the other cases there instead, sampled as the
 * `compare()` asks, and never alarms.
 */
export declare function benchmark(name: string, run: BenchmarkRun, options?: BenchmarkCaseOptions): BenchmarkCase;
/**
 * Compares cases with each other — one library's implementation against another's, say — on the
 * working tree's build, rather than each against its baseline. The first case is the reference.
 *
 * Every page load runs the whole file. Import what only one case needs inside that case, before the
 * part it times, to keep it out of the others' samples.
 */
export declare function compare(name: string, compared: BenchmarkCase[], sampling?: SamplingOptions): void;
export interface BenchPage {
  /** The cases measured across the builds: every case no `compare()` took. */
  cases: Array<{
    name: string;
    sampling: SamplingOptions;
    alarms?: BenchmarkCaseOptions['alarms'];
  }>;
  /** The file's `compare()` calls, with their cases' names in order. */
  comparisons: Array<{
    name: string;
    cases: string[];
    sampling: SamplingOptions;
  }>;
  /** Every metric recorded so far, by name. */
  metricDefinitions: () => Record<string, MetricDefinition>;
  /** Runs one iteration of a case, and returns what it recorded, by series. */
  sample: (name: string) => Promise<Record<string, number>>;
}
declare global {
  interface Window {
    /** Set by `markPageReady()` once the benchmark file has registered its cases. */
    benchmarkPage?: BenchPage;
    /** Exposed by the runner: forwards a CDP command to this page's session. */
    benchmarkCdp?: (method: string, params?: Record<string, unknown>) => Promise<unknown>;
  }
}
/**
 * Called by the generated page entry after it has imported the benchmark file. The runner waits for
 * `window.benchmarkPage`.
 */
export declare function markPageReady(): void;