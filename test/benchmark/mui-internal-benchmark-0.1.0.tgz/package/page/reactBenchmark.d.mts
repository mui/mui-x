import type * as React from 'react';
import type { BenchmarkInteraction, CaseOptions } from "../caseRuntime.mjs";
import type { SamplingOptions } from "../sampling.mjs";
import type { RunMetricAlarm } from "../runReport/schema.mjs";
import type { BenchmarkCase } from "./page.mjs";
export interface ReactBenchmarkOptions extends CaseOptions, SamplingOptions {
  /**
   * This benchmark's own alarm for `render` and `bench:paint`, in place of the default 5% `error`
   * band: a lower band for a benchmark that matters more, a higher one for one that matters less,
   * or `false` for a benchmark that never alarms.
   */
  alarm?: RunMetricAlarm | false;
}
/**
 * Registers a React benchmark case: every sample mounts `renderFn()`, runs the interaction, waits
 * for the paint and unmounts. It records the renders React's profiler captured and the time to
 * paint; custom metrics recorded along the way are reported with them.
 */
export declare function reactBenchmark(name: string, renderFn: () => React.ReactElement, interactionOrOptions?: BenchmarkInteraction | ReactBenchmarkOptions, maybeOptions?: ReactBenchmarkOptions): BenchmarkCase;