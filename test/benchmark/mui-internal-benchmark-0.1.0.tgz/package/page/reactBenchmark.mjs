import { measureIteration, MILLISECONDS, PAINT_METRIC_NAME, splitCaseArgs } from "../caseRuntime.mjs";
import { DiscreteMetric } from "../DiscreteMetric.mjs";
import { ScalarMetric } from "../ScalarMetric.mjs";
import { DEFAULT_ERROR_BAND } from "../runReport/analyzeRun.mjs";
import { benchmark } from "./page.mjs";
// Render time and paint both alarm: render is React running the components, while paint adds what
// follows — the commit, injected styles, style recalculation and layout — so a styling or DOM
// regression can show in paint alone. Both alarm once a change for the worse is confidently 5%,
// unless the benchmark sets its own `alarm`; smaller confirmed changes show on the dashboard and are
// left to the timelines. The render count is informational: an extra render matters only through the time it
// adds, which render time already measures. So is the per-phase split.
const TIME_ALARM = {
  error: DEFAULT_ERROR_BAND
};
const renderMetric = new ScalarMetric({
  name: 'render',
  format: MILLISECONDS,
  alarm: TIME_ALARM
});
const renderCountMetric = new DiscreteMetric({
  name: 'render:count'
});
const paintMetric = new ScalarMetric({
  name: PAINT_METRIC_NAME,
  format: MILLISECONDS,
  alarm: TIME_ALARM
});
const phaseMetrics = new Map();
function phaseMetricOf(phase) {
  let metric = phaseMetrics.get(phase);
  if (!metric) {
    metric = new ScalarMetric({
      name: `render:${phase}`,
      format: MILLISECONDS
    });
    phaseMetrics.set(phase, metric);
  }
  return metric;
}

/**
 * Registers a React benchmark case: every sample mounts `renderFn()`, runs the interaction, waits
 * for the paint and unmounts. It records the renders React's profiler captured and the time to
 * paint; custom metrics recorded along the way are reported with them.
 */
export function reactBenchmark(name, renderFn, interactionOrOptions, maybeOptions) {
  const {
    interaction,
    options
  } = splitCaseArgs(interactionOrOptions, maybeOptions);
  const run = async ({
    cdp
  }) => {
    const result = await measureIteration(renderFn, interaction, options, {
      cdp
    });

    // Render time is reported as totals rather than per render: an interaction's render count
    // follows whatever the browser coalesced, so per-render values would not line up across
    // iterations. The per-phase split only adds information when there is more than one phase.
    if (result.renders.length > 0) {
      const byPhase = new Map();
      let total = 0;
      for (const render of result.renders) {
        byPhase.set(render.phase, (byPhase.get(render.phase) ?? 0) + render.actualDuration);
        total += render.actualDuration;
      }
      renderMetric.record(total);
      renderCountMetric.record(result.renders.length);
      if (byPhase.size > 1) {
        for (const [phase, duration] of byPhase) {
          phaseMetricOf(phase).record(duration);
        }
      }
    }
    for (const {
      id,
      start,
      end
    } of result.paints) {
      paintMetric.record(end - start, id === undefined ? undefined : {
        id
      });
    }
  };
  const alarm = options?.alarm;
  return benchmark(name, run, {
    ...options,
    alarms: alarm === undefined ? undefined : {
      [renderMetric.name]: alarm,
      [paintMetric.name]: alarm
    }
  });
}