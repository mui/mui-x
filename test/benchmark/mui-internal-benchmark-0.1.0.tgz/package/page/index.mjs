// `@mui/internal-benchmark/page`: what a benchmark file for the `benchmark` CLI imports.

export * from "../publicApi.mjs";
export { benchmark, compare, markPageReady } from "./page.mjs";
export { reactBenchmark } from "./reactBenchmark.mjs";