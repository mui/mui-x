import { execa } from 'execa';
import { z } from 'zod/v4';
import envCi from 'env-ci';
import { ciReportUploadSchema } from "./ciReportUploadSchema.mjs";
export { ciReportUploadSchema } from "./ciReportUploadSchema.mjs";
async function getGitInfo() {
  const [commit, branch, commitTime] = await Promise.all([execa('git', ['rev-parse', 'HEAD']), execa('git', ['branch', '--show-current']), execa('git', ['log', '-1', '--format=%ct', 'HEAD'])]);
  return {
    commitSha: commit.stdout,
    branch: branch.stdout,
    commitTimestamp: Number(commitTime.stdout) * 1000
  };
}
const renderStatsSchema = z.object({
  id: z.string(),
  phase: z.enum(['mount', 'update', 'nested-update']),
  startTime: z.number(),
  actualDuration: z.number(),
  stdDev: z.number(),
  outliers: z.number()
});
const metricStatsSchema = z.object({
  mean: z.number(),
  stdDev: z.number(),
  outliers: z.number()
});
const benchmarkReportEntrySchema = z.object({
  iterations: z.number(),
  totalDuration: z.number(),
  renders: z.array(renderStatsSchema),
  metrics: z.record(z.string(), metricStatsSchema)
});
const benchmarkReportSchema = z.record(z.string(), benchmarkReportEntrySchema);
const metricDefinitionSchema = z.object({
  kind: z.enum(['scalar', 'discrete']),
  format: z.custom().optional(),
  alarm: z.object({
    direction: z.enum(['lowerIsBetter', 'higherIsBetter']).optional(),
    warn: z.number().min(0).optional(),
    error: z.number().min(0).optional()
  }).optional()
});
const benchmarkBaseUploadSchema = ciReportUploadSchema('benchmark', 1, benchmarkReportSchema).extend({
  // Per-metric config for custom metrics, hoisted to the top level (keyed by metric name) so
  // it is stored once rather than duplicated in every report entry. Optional and additive.
  metricDefinitions: z.record(z.string(), metricDefinitionSchema).optional()
});
export const benchmarkUploadSchema = benchmarkBaseUploadSchema.extend({
  base: benchmarkBaseUploadSchema.optional()
});
export async function getCiMetadata() {
  const ciInfo = envCi();
  const gitInfo = await getGitInfo();
  return {
    timestamp: Date.now(),
    repo: ciInfo.slug ?? '',
    prNumber: ciInfo.pr ? Number(ciInfo.pr) : undefined,
    branch: gitInfo.branch || process.env.BENCHMARK_BRANCH || (ciInfo.isPr ? ciInfo.prBranch : ciInfo.branch) || '',
    commitSha: gitInfo.commitSha,
    commitTimestamp: gitInfo.commitTimestamp
  };
}