/**
 * `*.bench.tsx` files: cases defined with `@mui/internal-benchmark/page`, measured by the interleaved
 * engine. Each file gets a generated page that loads it, so the file itself needs no page, config or
 * entry of its own.
 */
/** Where the generated pages live, under `src/`. Ignored from the inside, like `.benchmark/`. */
export declare const BENCH_PAGES_DIR = "__bench__";
export interface BenchFile {
  /** The benchmark file, posix, relative to `src`. */
  file: string;
  /** The generated page that runs it, posix, relative to `src`. */
  page: string;
}
/** The `*.bench.tsx` files under `src/`, optionally filtered by path, sorted. */
export declare function discoverBenchFiles(options: {
  harnessDir: string;
  filters?: string[];
}): Promise<BenchFile[]>;
/**
 * Writes a page per benchmark file into `src/__bench__/`, replacing whatever was there, so pages
 * of deleted files do not linger as build inputs.
 */
export declare function writeBenchPages(harnessDir: string, benchFiles: BenchFile[]): Promise<void>;