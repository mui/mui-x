import type { BenchmarkRunReport } from "../runReport/index.mjs";
import type { SamplingOptions } from "../sampling.mjs";
export interface RunBenchmarksOptions {
  /** The harness package directory (where the command was run). */
  harnessDir: string;
  /** Only run benchmark files whose path under `src` contains one of these, case-insensitively. */
  filters?: string[];
  /**
   * The build the working tree is compared against: a revision, on its own or as `git:<rev>`.
   * Defaults to `HEAD~1`, the parent commit.
   */
  baseline?: string;
  /**
   * Command that builds the publishable workspace packages. Run for every ref — in each ref's own
   * checkout, and in the working tree — so both sides of a comparison are built the same way.
   * Defaults to `pnpm release:build`.
   */
  buildCmd?: string;
  /**
   * Where to write the JSON report, which `benchmark upload` sends to the dashboard. Defaults to
   * `.benchmark/results/report.json`.
   */
  out?: string;
  /** Defaults, for the whole run, for the sampling options a benchmark doesn't set itself. */
  sampling?: SamplingOptions;
  /** Only run benchmarks whose name matches this regular expression, like Vitest's `-t`. */
  testNamePattern?: string;
  /**
   * How the results are printed: `default`, tables for reading, or `json`, the analysis as JSON on
   * stdout — medians, intervals and verdicts — for a program to read.
   */
  reporter?: 'default' | 'json';
  /**
   * Stops the run: it rejects once the workspace is put back, without a report.
   */
  signal?: AbortSignal;
  /**
   * Also record a performance trace around every sample, to open in DevTools' Performance panel,
   * for a fixed number of rounds. Tracing slows the code it records, so the report's numbers are
   * only indicative.
   */
  profile?: boolean;
  /**
   * More Chromium flags, after the ones every run uses: a GPU backend for a local run, such as
   * `--use-angle=metal`, or a software one for WebGL in CI. Both builds share the browser, so a
   * comparison stays fair, and the report records them, since they change what the numbers mean.
   */
  launchArgs?: string[];
}
/**
 * Benchmarks a harness's `*.bench.tsx` files across two builds of the workspace — the working tree
 * and a baseline — and writes, prints, and returns the run report, failed benchmarks included.
 *
 * Both builds are packed from their own commit and installed into the harness the same way, so
 * neither resolves the library through a workspace link.
 */
export declare function runBenchmarks(options: RunBenchmarksOptions): Promise<BenchmarkRunReport>;