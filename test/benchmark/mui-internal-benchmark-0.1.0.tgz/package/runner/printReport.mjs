/* eslint-disable no-console */

import { dim, printTable, red } from "../format.mjs";
import { analyzeRun, benchmarkTable, formatRounds, findRegressions, formatComparison, formatRunSummary, runReportFootnote } from "../runReport/index.mjs";
function printBenchmark(analysis) {
  const {
    columns,
    rows
  } = benchmarkTable(analysis);
  const cells = rows.map(row => row.cells);
  printTable(columns.map(({
    header
  }, column) => ({
    header,
    width: Math.max(header.length, ...cells.map(row => row[column].length))
  })), cells, undefined, `${analysis.benchmark.name}  (${analysis.benchmark.file} · ${formatRounds(analysis.benchmark)})`);
}

/**
 * Prints a run report as the terminal tables, and says up front what regressed — the same analysis
 * the pull request comment and the dashboard show.
 */
export function printRunReport(report) {
  const analyses = analyzeRun(report);
  for (const analysis of analyses) {
    if (analysis.benchmark.error) {
      console.log(red(`✖ ${analysis.benchmark.name}: ${analysis.benchmark.error}`));
      continue;
    }
    printBenchmark(analysis);
  }
  const regressions = findRegressions(analyses);
  console.log('');
  for (const {
    benchmark,
    metric,
    comparison
  } of regressions) {
    console.log(red(`⚠ ${benchmark} · ${metric} · ${formatComparison(comparison)}`));
  }
  console.log(formatRunSummary(analyses, regressions, report.durationMs));
  console.log(dim(runReportFootnote()));
}