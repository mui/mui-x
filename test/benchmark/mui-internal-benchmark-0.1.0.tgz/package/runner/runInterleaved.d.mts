import type { RunBenchmark, RunMetricDefinition } from "../runReport/index.mjs";
import type { SamplingOptions } from "../sampling.mjs";
import type { BenchFile } from "./benchFiles.mjs";
import type { ResolvedRef } from "./refs.mjs";
/**
 * Runs the cases of `*.bench.tsx` files in Playwright. A file's benchmarks run in one tab, which
 * loads each build's page once per round and samples every benchmark of the file still sampling
 * there, with garbage collected before each sample. A page is reloaded every round, and every
 * variant runs in the same renderer process: whatever a page or a process holds on to — the JIT tier
 * its code settled into, the heap it grew — then never favours one variant for the whole benchmark,
 * which paired rounds could not tell from a real difference. Interactions get trusted input through
 * a CDP session the tab is bridged to. Pages load in a shuffled order every round, and a benchmark's
 * variants on the same page are sampled in a shuffled order too, so the samples are round-aligned and
 * can be compared on paired differences.
 */
export interface RunInterleavedOptions {
  /** Where each ref's pages were built, one directory per ref id. */
  buildsDir: string;
  benchFiles: BenchFile[];
  /** The builds a benchmark file compares: the working tree first, then the baseline. */
  benchRefs: ResolvedRef[];
  launchArgs: string[];
  /** Defaults for the sampling options a benchmark doesn't set itself, from `getSampling`. */
  sampling?: SamplingOptions;
  /** Only run benchmarks whose name matches this, like Vitest's `-t`. */
  testNamePattern?: RegExp;
  /** Stops the run: the browser closes, and the run rejects. */
  signal?: AbortSignal;
  /**
   * Profiles the run: every benchmark samples exactly the run's sample size (default
   * `PROFILE_ROUNDS`), whatever it sets itself, with a performance trace around each sample written
   * under `tracesDir`, to open in DevTools.
   */
  profile?: {
    tracesDir: string;
  };
}
export interface InterleavedResults {
  benchmarks: RunBenchmark[];
  metrics: Record<string, RunMetricDefinition>;
  /** The browser as it reports itself, e.g. `151.0.7922.34`. */
  browserVersion: string;
}
/**
 * Serves the builds, launches the browser, lists every benchmark the run was asked for, then
 * measures them a file at a time.
 */
export declare function runInterleaved(options: RunInterleavedOptions): Promise<InterleavedResults>;