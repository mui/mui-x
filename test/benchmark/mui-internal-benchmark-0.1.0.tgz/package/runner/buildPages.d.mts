import type { PackedPackage } from "../utils/packWorkspace.mjs";
import type { BenchFile } from "./benchFiles.mjs";
import type { ResolvedRef } from "./refs.mjs";
/**
 * Puts the repository's manifest and lockfile back as they were, byte for byte, and installs from
 * them: the lockfile already satisfies the manifest, so nothing is resolved again.
 */
export declare function restoreWorkspace(repoRoot: string, outputDir: string): Promise<void>;
/**
 * Builds the benchmark pages against one ref's packed build, in place with the harness's own vite
 * config, so only the library differs from a plain `vite build`. The pins stay until
 * `restoreWorkspace` puts the repository back.
 */
export declare function buildRefPages(options: {
  /** The harness package directory, built in place. */
  harnessDir: string;
  /** The workspace root, whose overrides the tree inherits. */
  repoRoot: string;
  /** The ref being built. */
  ref: ResolvedRef;
  /** That ref's packed workspace packages. */
  packages: PackedPackage[];
  /** The run's output directory, where the manifest the run replaced is kept. */
  outputDir: string;
  /** Absolute output directory for the built pages. */
  outDir: string;
  /** The benchmark files the run measures: only their pages are built. */
  benchFiles: BenchFile[];
}): Promise<void>;