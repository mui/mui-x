/**
 * A build a run measures: the working tree (`current`), or the revision it is compared against
 * (`baseline`). `variant` names its pages, its build directory and its entry in the report.
 * `requested` is the revision as it was given, which is what a report shows.
 */
export type ResolvedRef = {
  variant: 'current';
  sha?: undefined;
  requested?: undefined;
} | {
  variant: 'baseline';
  sha: string;
  requested: string;
};
/** What a ref is called in a report: the working tree, or the revision the run was given. */
export declare function refLabel(ref: ResolvedRef): string;
export declare const WORKTREE_REF: ResolvedRef;
/** Resolves the baseline to the commit behind it, so a run stays interpretable after the fact. */
export declare function resolveBaselineRef(token: string | undefined, repoRoot: string): Promise<ResolvedRef>;