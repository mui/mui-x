import type { BenchmarkRunReport } from "../runReport/index.mjs";
/**
 * Prints a run report as the terminal tables, and says up front what regressed — the same analysis
 * the pull request comment and the dashboard show.
 */
export declare function printRunReport(report: BenchmarkRunReport): void;