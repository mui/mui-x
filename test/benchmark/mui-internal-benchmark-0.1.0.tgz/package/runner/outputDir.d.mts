/** Everything a run writes lives here, so there is one thing to ignore and deleting it resets. */
export declare const OUTPUT_DIR = ".benchmark";
/**
 * Marks a generated directory ignored from the inside: a `.gitignore` holding `*` ignores its
 * contents and itself. Tools that read only the root ignore file still need an entry there.
 */
export declare function markIgnored(dir: string): Promise<void>;
/** Creates the output directory, marked ignored. */
export declare function prepareOutputDir(harnessDir: string): Promise<string>;
/** Where a run writes its JSON report, unless told otherwise. */
export declare function resultsPathOf(harnessDir: string): string;
/** Where the pages of every ref are built, one directory per variant. */
export declare function buildsDirOf(harnessDir: string): string;