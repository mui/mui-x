import type { Plugin } from 'vite';
/**
 * Vite plugin for a benchmark harness.
 *
 * The harness keeps its own vite config and runs plain `vite` / `vite build` / `vite preview`; this
 * plugin only contributes what is derived from its `*.bench.tsx` files:
 *
 * - A generated page per benchmark file, under `src/__bench__/`, and those pages as the build's
 *   entry points.
 * - A clear error when a page imports Vitest, or the Vitest entry of this package instead of
 *   `@mui/internal-benchmark/page`.
 * - `root` at the harness's `src/`, as an MPA (vite defaults to `spa`, whose fallback would rewrite
 *   unmatched urls toward a root `index.html` that does not exist here), and an index page listing
 *   the benchmark files.
 *
 * It deliberately never resolves refs, so a plain `vite build` needs no git history.
 */
export interface BenchmarkPluginOptions {
  /**
   * The harness package directory. Defaults to the current working directory, which is where vite
   * is run from.
   */
  harnessDir?: string;
}
declare module 'vite' {
  interface UserConfig {
    /** What the `benchmark` CLI asks of a build of the harness's pages. */
    benchmark?: {
      /**
       * Build only these benchmark files' pages (posix, relative to `src`): the files the run
       * selected. A page the run doesn't measure isn't built, so it can't fail the build.
       */
      files?: string[];
    };
  }
}
/** Creates the benchmark harness plugin. */
export declare function benchmarkPlugin(options?: BenchmarkPluginOptions): Plugin;