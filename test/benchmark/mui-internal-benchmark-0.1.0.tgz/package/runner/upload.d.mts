export interface UploadReportOptions {
  /** The harness package directory, where a run writes its report by default. */
  harnessDir: string;
  /** The report to upload. Defaults to the one a run writes, `.benchmark/results/report.json`. */
  file?: string;
  /** The dashboard timeline to upload into, in place of the branch's. */
  timeline?: string;
}
/**
 * Uploads a report that a `benchmark` run wrote, and refreshes the pull request comment.
 *
 * The dashboard files the report under the commit CI is building, so a report measured on another
 * commit is refused rather than filed under the wrong one. Validates before sending because the
 * server stores `report` without inspecting it. A failure to refresh the comment does not fail the
 * upload: the report has landed, and the next sync shows it.
 */
export declare function uploadReportFile(options: UploadReportOptions): Promise<void>;