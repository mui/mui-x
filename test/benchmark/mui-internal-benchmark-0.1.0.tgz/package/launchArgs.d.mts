export declare const BENCHMARK_LAUNCH_ARGS: string[];
/**
 * The launch flags, `base` followed by a caller's `extra`. Chromium keeps only the last
 * `--js-flags`, so a caller's V8 flags would silently drop `--expose-gc`, and with it the forced
 * GC between iterations: every `--js-flags` value is joined into one instead.
 */
export declare function withLaunchArgs(extra: readonly string[], base?: readonly string[]): string[];
/** The viewport every runner measures at. */
export declare const BENCHMARK_VIEWPORT: {
  width: number;
  height: number;
};