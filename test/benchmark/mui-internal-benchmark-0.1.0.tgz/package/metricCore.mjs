/** The name a sub-series is reported under: `name#id`, or `name` for the base series. */
export function seriesName(name, id) {
  return id === undefined ? name : `${name}#${id}`;
}

/** The metric a series belongs to: `name#id` without its `#id`. */
export function baseMetricName(series) {
  const hashIndex = series.indexOf('#');
  return hashIndex === -1 ? series : series.slice(0, hashIndex);
}

/** Where recorded values go: the runtime a benchmark runs under installs one. */

let recorder = metric => {
  throw new Error(`${metric.constructor.name}.record() was called outside a benchmark runtime. Import metrics from ` + '`@mui/internal-benchmark` inside a benchmark file.');
};
export function setMetricRecorder(next) {
  recorder = next;
}

/**
 * Base class for custom benchmark metrics. Use `ScalarMetric` or `DiscreteMetric`.
 *
 * A single instance can be declared at module scope and reused across tests and loop iterations,
 * inside or outside React; the active runtime decides which test or sample a value belongs to.
 */
export class Metric {
  constructor(config) {
    this.config = typeof config === 'string' ? {
      name: config
    } : config;
    this.name = this.config.name;
    if (this.name.includes('#')) {
      throw new Error(`Metric name "${this.name}" must not contain "#" — it is reserved as the sub-series separator.`);
    }
  }

  /**
   * Records a single measured value. Pass `options.id` to split into a labeled sub-series.
   */
  record(value, options) {
    recorder(this, value, options);
  }
}