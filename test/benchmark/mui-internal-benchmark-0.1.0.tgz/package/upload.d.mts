import type { BenchmarkUpload } from "./ciReport.mjs";
/**
 * Uploads a benchmark report to the CI report store.
 *
 * Validated before sending: the server stores `report` without inspecting it, so a malformed one
 * would be accepted here and only fail later, when the dashboard tried to render it.
 */
declare function uploadCiReport(report: BenchmarkUpload): Promise<void>;
export { uploadCiReport };