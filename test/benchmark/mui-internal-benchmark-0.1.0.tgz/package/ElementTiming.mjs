import * as React from 'react';
import { jsx as _jsx } from "react/jsx-runtime";
export function ElementTiming({
  name
}) {
  return /*#__PURE__*/_jsx("span", {
    elementtiming: name,
    style: {
      position: 'fixed',
      top: 0,
      left: 0,
      opacity: 0.01,
      pointerEvents: 'none',
      fontSize: 1
    },
    children: "\xA0"
  });
}