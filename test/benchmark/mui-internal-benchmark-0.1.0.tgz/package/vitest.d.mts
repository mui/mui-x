import type { ViteUserConfig } from 'vitest/config';
export interface CreateBenchmarkVitestConfigOptions {
  /**
   * Path to save benchmark results JSON file. If not provided, results will not be saved to disk.
   */
  outputPath?: string;
  /**
   * Path to a prior benchmark results JSON file. When set, its contents are
   * inlined as the `base` field of the head upload so the dashboard and PR
   * comment can render a comparison without fetching a separate base
   * artifact from S3. Also settable via the `BENCHMARK_BASELINE_PATH` env var.
   */
  baselinePath?: string;
  /**
   * Additional Chromium launch arguments.
   */
  launchArgs?: string[];
  /**
   * Run each `benchmark()` case as an interactive profiling session in a headed
   * browser instead of the automated measurement loop. Each case renders a
   * control panel with Render / Unmount / Finish buttons so you can start the
   * DevTools profiler before the component mounts. Profiling auto-opens DevTools
   * and runs headed (pass `viewport` to size the window). Also settable via
   * `BENCHMARK_PROFILE=true`.
   */
  profile?: boolean;
  /**
   * Browser viewport — and, in profile mode, the matching window size. Defaults to 1920x1080 for
   * both measurement and profiling. Also settable via `BENCHMARK_VIEWPORT` (e.g. `2560x1440`).
   */
  viewport?: {
    width: number;
    height: number;
  };
}
export declare function createBenchmarkVitestConfig(options?: CreateBenchmarkVitestConfigOptions): ViteUserConfig;