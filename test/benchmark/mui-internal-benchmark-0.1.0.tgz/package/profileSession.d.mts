import type { BenchmarkCaseRuntime } from "./types.mjs";
export declare function runProfileSession(name: string, runtime: BenchmarkCaseRuntime): Promise<void>;