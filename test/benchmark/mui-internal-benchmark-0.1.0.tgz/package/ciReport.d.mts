import { z } from 'zod/v4';
export { ciReportUploadSchema } from "./ciReportUploadSchema.mjs";
declare const renderStatsSchema: z.ZodObject<{
  id: z.ZodString;
  phase: z.ZodEnum<{
    mount: "mount";
    "nested-update": "nested-update";
    update: "update";
  }>;
  startTime: z.ZodNumber;
  actualDuration: z.ZodNumber;
  stdDev: z.ZodNumber;
  outliers: z.ZodNumber;
}, z.core.$strip>;
declare const metricStatsSchema: z.ZodObject<{
  mean: z.ZodNumber;
  stdDev: z.ZodNumber;
  outliers: z.ZodNumber;
}, z.core.$strip>;
declare const benchmarkReportEntrySchema: z.ZodObject<{
  iterations: z.ZodNumber;
  totalDuration: z.ZodNumber;
  renders: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    phase: z.ZodEnum<{
      mount: "mount";
      "nested-update": "nested-update";
      update: "update";
    }>;
    startTime: z.ZodNumber;
    actualDuration: z.ZodNumber;
    stdDev: z.ZodNumber;
    outliers: z.ZodNumber;
  }, z.core.$strip>>;
  metrics: z.ZodRecord<z.ZodString, z.ZodObject<{
    mean: z.ZodNumber;
    stdDev: z.ZodNumber;
    outliers: z.ZodNumber;
  }, z.core.$strip>>;
}, z.core.$strip>;
declare const benchmarkReportSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
  iterations: z.ZodNumber;
  totalDuration: z.ZodNumber;
  renders: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    phase: z.ZodEnum<{
      mount: "mount";
      "nested-update": "nested-update";
      update: "update";
    }>;
    startTime: z.ZodNumber;
    actualDuration: z.ZodNumber;
    stdDev: z.ZodNumber;
    outliers: z.ZodNumber;
  }, z.core.$strip>>;
  metrics: z.ZodRecord<z.ZodString, z.ZodObject<{
    mean: z.ZodNumber;
    stdDev: z.ZodNumber;
    outliers: z.ZodNumber;
  }, z.core.$strip>>;
}, z.core.$strip>>;
declare const metricDefinitionSchema: z.ZodObject<{
  kind: z.ZodEnum<{
    discrete: "discrete";
    scalar: "scalar";
  }>;
  format: z.ZodOptional<z.ZodCustom<Intl.NumberFormatOptions, Intl.NumberFormatOptions>>;
  alarm: z.ZodOptional<z.ZodObject<{
    direction: z.ZodOptional<z.ZodEnum<{
      higherIsBetter: "higherIsBetter";
      lowerIsBetter: "lowerIsBetter";
    }>>;
    warn: z.ZodOptional<z.ZodNumber>;
    error: z.ZodOptional<z.ZodNumber>;
  }, z.core.$strip>>;
}, z.core.$strip>;
declare const benchmarkBaseUploadSchema: z.ZodObject<{
  version: z.ZodLiteral<number>;
  timestamp: z.ZodNumber;
  commitSha: z.ZodString;
  repo: z.ZodString;
  reportType: z.ZodLiteral<string>;
  prNumber: z.ZodOptional<z.ZodNumber>;
  branch: z.ZodString;
  commitTimestamp: z.ZodOptional<z.ZodNumber>;
  report: z.ZodRecord<z.ZodString, z.ZodObject<{
    iterations: z.ZodNumber;
    totalDuration: z.ZodNumber;
    renders: z.ZodArray<z.ZodObject<{
      id: z.ZodString;
      phase: z.ZodEnum<{
        mount: "mount";
        "nested-update": "nested-update";
        update: "update";
      }>;
      startTime: z.ZodNumber;
      actualDuration: z.ZodNumber;
      stdDev: z.ZodNumber;
      outliers: z.ZodNumber;
    }, z.core.$strip>>;
    metrics: z.ZodRecord<z.ZodString, z.ZodObject<{
      mean: z.ZodNumber;
      stdDev: z.ZodNumber;
      outliers: z.ZodNumber;
    }, z.core.$strip>>;
  }, z.core.$strip>>;
  metricDefinitions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
    kind: z.ZodEnum<{
      discrete: "discrete";
      scalar: "scalar";
    }>;
    format: z.ZodOptional<z.ZodCustom<Intl.NumberFormatOptions, Intl.NumberFormatOptions>>;
    alarm: z.ZodOptional<z.ZodObject<{
      direction: z.ZodOptional<z.ZodEnum<{
        higherIsBetter: "higherIsBetter";
        lowerIsBetter: "lowerIsBetter";
      }>>;
      warn: z.ZodOptional<z.ZodNumber>;
      error: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
  }, z.core.$strip>>>;
}, z.core.$strip>;
export declare const benchmarkUploadSchema: z.ZodObject<{
  version: z.ZodLiteral<number>;
  timestamp: z.ZodNumber;
  commitSha: z.ZodString;
  repo: z.ZodString;
  reportType: z.ZodLiteral<string>;
  prNumber: z.ZodOptional<z.ZodNumber>;
  branch: z.ZodString;
  commitTimestamp: z.ZodOptional<z.ZodNumber>;
  report: z.ZodRecord<z.ZodString, z.ZodObject<{
    iterations: z.ZodNumber;
    totalDuration: z.ZodNumber;
    renders: z.ZodArray<z.ZodObject<{
      id: z.ZodString;
      phase: z.ZodEnum<{
        mount: "mount";
        "nested-update": "nested-update";
        update: "update";
      }>;
      startTime: z.ZodNumber;
      actualDuration: z.ZodNumber;
      stdDev: z.ZodNumber;
      outliers: z.ZodNumber;
    }, z.core.$strip>>;
    metrics: z.ZodRecord<z.ZodString, z.ZodObject<{
      mean: z.ZodNumber;
      stdDev: z.ZodNumber;
      outliers: z.ZodNumber;
    }, z.core.$strip>>;
  }, z.core.$strip>>;
  metricDefinitions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
    kind: z.ZodEnum<{
      discrete: "discrete";
      scalar: "scalar";
    }>;
    format: z.ZodOptional<z.ZodCustom<Intl.NumberFormatOptions, Intl.NumberFormatOptions>>;
    alarm: z.ZodOptional<z.ZodObject<{
      direction: z.ZodOptional<z.ZodEnum<{
        higherIsBetter: "higherIsBetter";
        lowerIsBetter: "lowerIsBetter";
      }>>;
      warn: z.ZodOptional<z.ZodNumber>;
      error: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
  }, z.core.$strip>>>;
  base: z.ZodOptional<z.ZodObject<{
    version: z.ZodLiteral<number>;
    timestamp: z.ZodNumber;
    commitSha: z.ZodString;
    repo: z.ZodString;
    reportType: z.ZodLiteral<string>;
    prNumber: z.ZodOptional<z.ZodNumber>;
    branch: z.ZodString;
    commitTimestamp: z.ZodOptional<z.ZodNumber>;
    report: z.ZodRecord<z.ZodString, z.ZodObject<{
      iterations: z.ZodNumber;
      totalDuration: z.ZodNumber;
      renders: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        phase: z.ZodEnum<{
          mount: "mount";
          "nested-update": "nested-update";
          update: "update";
        }>;
        startTime: z.ZodNumber;
        actualDuration: z.ZodNumber;
        stdDev: z.ZodNumber;
        outliers: z.ZodNumber;
      }, z.core.$strip>>;
      metrics: z.ZodRecord<z.ZodString, z.ZodObject<{
        mean: z.ZodNumber;
        stdDev: z.ZodNumber;
        outliers: z.ZodNumber;
      }, z.core.$strip>>;
    }, z.core.$strip>>;
    metricDefinitions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
      kind: z.ZodEnum<{
        discrete: "discrete";
        scalar: "scalar";
      }>;
      format: z.ZodOptional<z.ZodCustom<Intl.NumberFormatOptions, Intl.NumberFormatOptions>>;
      alarm: z.ZodOptional<z.ZodObject<{
        direction: z.ZodOptional<z.ZodEnum<{
          higherIsBetter: "higherIsBetter";
          lowerIsBetter: "lowerIsBetter";
        }>>;
        warn: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodNumber>;
      }, z.core.$strip>>;
    }, z.core.$strip>>>;
  }, z.core.$strip>>;
}, z.core.$strip>;
export type RenderStats = z.infer<typeof renderStatsSchema>;
export type MetricStats = z.infer<typeof metricStatsSchema>;
export type BenchmarkMetricDefinition = z.infer<typeof metricDefinitionSchema>;
export type BenchmarkReportEntry = z.infer<typeof benchmarkReportEntrySchema>;
export type BenchmarkReport = z.infer<typeof benchmarkReportSchema>;
export type BenchmarkBaseUpload = z.infer<typeof benchmarkBaseUploadSchema>;
export type BenchmarkUpload = z.infer<typeof benchmarkUploadSchema>;
export declare function getCiMetadata(): Promise<{
  timestamp: number;
  repo: string;
  prNumber: number | undefined;
  branch: string;
  commitSha: string;
  commitTimestamp: number;
}>;