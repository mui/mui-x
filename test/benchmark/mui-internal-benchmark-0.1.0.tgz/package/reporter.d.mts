import type { Reporter, TestCase } from 'vitest/node';
import type { IterationData } from "./types.mjs";
import type { BenchmarkReportEntry } from "./ciReport.mjs";
import "./taskMetaAugmentation.mjs";
declare function generateReportFromIterations(iterations: IterationData[]): BenchmarkReportEntry;
export interface BenchmarkReporterOptions {
  outputPath?: string;
  upload?: boolean;
  baselinePath?: string;
}
declare class BenchmarkReporter implements Reporter {
  private benchmarks;
  private metricDefinitions;
  private outputPath;
  private upload;
  private baselinePath;
  private hasFailures;
  constructor(options?: BenchmarkReporterOptions);
  onTestRunStart(): void;
  onTestCaseResult(testCase: TestCase): void;
  onTestRunEnd(): Promise<void>;
}
export { BenchmarkReporter, generateReportFromIterations };
export default BenchmarkReporter;