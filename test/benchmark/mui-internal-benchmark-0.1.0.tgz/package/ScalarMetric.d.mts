import { Metric } from "./metricCore.mjs";
import type { MetricKind } from "./types.mjs";
/**
 * A continuous measurement (timings, sizes, …), whose alarm bands are relative fractions.
 *
 * It offers a `console.time`-style timing helper:
 *
 * ```ts
 * const metric = new ScalarMetric({ name: 'render', format: { style: 'unit', unit: 'millisecond' } });
 * metric.time();
 * doWork();
 * metric.timeEnd(); // records the elapsed milliseconds
 * ```
 */
export declare class ScalarMetric extends Metric {
  readonly kind: MetricKind;
  private readonly pending;
  /** Starts a timer. Pass a `label` to time a sub-series; it maps to `record`'s `id`. */
  time(label?: string): void;
  /** Stops the timer started by `time(label)` and records the elapsed milliseconds. */
  timeEnd(label?: string): void;
}