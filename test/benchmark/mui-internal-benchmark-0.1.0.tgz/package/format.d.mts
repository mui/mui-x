export declare const dim: (s: string) => string;
export declare const red: (s: string) => string;
export declare const green: (s: string) => string;
export declare const yellow: (s: string) => string;
export declare const cyan: (s: string) => string;
export declare function fileUrl(filePath: string): string;
interface Column {
  header: string;
  width: number;
}
export declare function printTable(columns: Column[], rows: string[][], footer?: string, title?: string): void;
export {};