import * as React from 'react';
export declare function ElementTiming({
  name
}: {
  name: string;
}): React.JSX.Element;