export declare function calculateMean(values: number[]): number;
export declare function calculateStdDev(values: number[], mean: number): number;
/** The sample standard deviation, which an interval estimated from the values needs; 0 for fewer than 2. */
export declare function calculateSampleStdDev(values: number[], mean: number): number;
export declare function quantile(sorted: number[], q: number): number;
/**
 * Determines whether a value is a statistical outlier using the IQR method.
 * Values below Q1 - 1.5*IQR or above Q3 + 1.5*IQR are considered outliers.
 *
 * See https://en.wikipedia.org/wiki/Interquartile_range#Outliers
 */
export declare function isOutlier(value: number, q1: number, q3: number): boolean;
/**
 * Aggregates a series of samples into a mean, standard deviation, and outlier count using
 * IQR-based outlier removal. Falls back to the raw values when filtering would remove
 * everything. This is the shared aggregation core for custom metrics.
 */
export declare function aggregateSamples(values: number[]): {
  mean: number;
  stdDev: number;
  outliers: number;
};