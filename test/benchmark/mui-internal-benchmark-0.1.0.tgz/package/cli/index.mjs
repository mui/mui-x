#!/usr/bin/env node
import * as os from 'node:os';
import chalk from 'chalk';
import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';

// Self-referencing rather than `../../package.json`: this file is one directory deeper in the
// repository than in the published package, which is built from `build/`, so a relative path
// cannot reach the manifest from both — and the repository's workspace symlink hides the break.
import pkgJson from '@mui/internal-benchmark/package.json' with { type: 'json' };

/**
 * Everything `runBenchmarks` takes except the directory, which is where the command was run, with
 * its sampling overrides as flags of their own.
 */

const runCommand = {
  command: '$0 [filters...]',
  describe: "Benchmark a harness's *.bench.tsx files, the working tree against a baseline build, and write a JSON report. Run from the harness package.",
  builder: args => args.positional('filters', {
    type: 'string',
    array: true,
    describe: 'Only run benchmark files whose path under src contains this substring'
  }).option('baseline', {
    type: 'string',
    describe: 'The build to compare against: a revision, on its own or as git:<rev>. Defaults to HEAD~1, the parent commit; `code-infra baseline` resolves a fork point to pass here'
  }).option('build-cmd', {
    type: 'string',
    describe: "Command that builds the publishable workspace packages, in each ref's checkout and in the working tree. Default: pnpm release:build"
  }).option('out', {
    type: 'string',
    describe: 'Write the JSON report here, for `benchmark upload`. Default: .benchmark/results/report.json'
  }).option('testNamePattern', {
    alias: 't',
    type: 'string',
    describe: 'Only run benchmarks whose name matches this regular expression'
  }).option('reporter', {
    choices: ['default', 'json'],
    default: 'default',
    describe: 'How to print the results: tables, or the analysis as JSON on stdout (medians, intervals, verdicts), with everything else on stderr'
  }).option('profile', {
    type: 'boolean',
    default: false,
    describe: 'Also record a performance trace around every sample, for a fixed number of rounds, saved to open in DevTools. Tracing slows the code it records, so the report is only indicative'
  })
  // A repeated string, not `array: true`, which would also take the filters that follow.
  .option('launch-args', {
    type: 'string',
    // One flag, or several when it's repeated; not called when the flag is absent.
    coerce: value => [value].flat(),
    describe: 'A Chromium flag to add, such as --launch-args=--use-angle=metal for a GPU backend; repeat it for more. The report records them'
  }).option('sample-size', {
    type: 'number',
    describe: "Rounds before deciding whether to continue, for benchmarks that don't set their own (default 50); with --profile, the rounds to record (default 5)"
  }).option('timeout', {
    type: 'number',
    describe: "Minutes a benchmark may sample for, its sample size included, while an alarmed difference is unsettled against its band, for benchmarks that don't set their own (default 3)"
  }),
  handler: async argv => {
    if (argv.reporter === 'json') {
      // Stdout carries the JSON alone; what a run prints along the way is progress.
      /* eslint-disable no-console */
      console.log = console.error;
      console.info = console.error;
      /* eslint-enable no-console */
    }
    const {
      runBenchmarks
    } = await import("../runner/runBenchmarks.mjs");
    // A canceled CI job or a Ctrl+C stops the run: the browser closes and the workspace is put back,
    // and the run exits as the signal would have made it, without a stack trace per benchmark. A
    // second signal exits at once.
    const stop = new AbortController();
    const onSignal = signal => {
      process.exitCode = 128 + os.constants.signals[signal];
      if (stop.signal.aborted) {
        process.exit();
      }
      console.error(chalk.yellow(`\n${signal}: stopping, and putting the repository back…`));
      stop.abort(new Error(`Stopped by ${signal}.`));
    };
    process.on('SIGINT', onSignal);
    process.on('SIGTERM', onSignal);
    try {
      const report = await runBenchmarks({
        harnessDir: process.cwd(),
        filters: argv.filters ?? [],
        baseline: argv.baseline,
        buildCmd: argv.buildCmd,
        out: argv.out,
        testNamePattern: argv.testNamePattern,
        reporter: argv.reporter,
        profile: argv.profile,
        launchArgs: argv.launchArgs,
        sampling: {
          sampleSize: argv.sampleSize,
          timeout: argv.timeout
        },
        signal: stop.signal
      });
      // The report is written first, so the errors are readable and an upload can still report
      // them; then the run fails, as a test runner fails on any failed test.
      const failed = report.benchmarks.filter(benchmark => benchmark.error !== undefined).length;
      if (failed > 0) {
        console.error(chalk.red(`\n${failed} of ${report.benchmarks.length} benchmarks failed.`));
        process.exitCode = 1;
      }
    } catch (error) {
      if (!stop.signal.aborted) {
        throw error;
      }
    }
  }
};
const uploadCommand = {
  command: 'upload [file]',
  describe: 'Upload a report that a run wrote to the dashboard, and refresh the PR comment. Run from the harness package, in CI. Requires CIRCLE_OIDC_TOKEN_V2',
  builder: args => args.positional('file', {
    type: 'string',
    describe: 'The report to upload. Default: .benchmark/results/report.json'
  }).option('timeline', {
    type: 'string',
    default: process.env.BENCHMARK_TIMELINE,
    describe: "The dashboard timeline to upload into in place of the branch's, for a run against another baseline such as the last release. Defaults to BENCHMARK_TIMELINE"
  }),
  handler: async argv => {
    const {
      uploadReportFile
    } = await import("../runner/upload.mjs");
    await uploadReportFile({
      harnessDir: process.cwd(),
      file: argv.file,
      timeline: argv.timeline
    });
  }
};

// chalk honours FORCE_COLOR and --no-color, not the NO_COLOR convention (https://no-color.org):
// set to anything but an empty string, it turns color off.
if (process.env.NO_COLOR) {
  chalk.level = 0;
}
let globalArgv = {};
await yargs(hideBin(process.argv)).scriptName('benchmark').option('verbose', {
  alias: 'v',
  type: 'boolean',
  default: false,
  describe: 'Increase output verbosity',
  global: true
}).middleware(argv => {
  globalArgv = argv;
}, true).command(uploadCommand).command(runCommand).fail((msg, err, yargsInstance) => {
  if (msg) {
    yargsInstance.showHelp();
    console.error(`\n${msg}`);
  } else if (err) {
    console.error(err.message);
    if (globalArgv.verbose) {
      console.error(chalk.dim(err.stack));
    }
  }
  process.exit(1);
}).strict().help().version(pkgJson.version).parseAsync();