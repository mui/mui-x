import { Metric } from "./metricCore.mjs";
/**
 * A continuous measurement (timings, sizes, …), whose alarm bands are relative fractions.
 *
 * It offers a `console.time`-style timing helper:
 *
 * ```ts
 * const metric = new ScalarMetric({ name: 'render', format: { style: 'unit', unit: 'millisecond' } });
 * metric.time();
 * doWork();
 * metric.timeEnd(); // records the elapsed milliseconds
 * ```
 */
export class ScalarMetric extends Metric {
  kind = 'scalar';
  pending = new Map();

  /** Starts a timer. Pass a `label` to time a sub-series; it maps to `record`'s `id`. */
  time(label) {
    const key = label ?? '';
    if (this.pending.has(key)) {
      throw new Error(`${this.name}.time(${label ? `"${label}"` : ''}) was called while a timer is already running for that label.`);
    }
    this.pending.set(key, performance.now());
  }

  /** Stops the timer started by `time(label)` and records the elapsed milliseconds. */
  timeEnd(label) {
    // Capture the end time first so the map lookup/delete below isn't part of the measurement.
    const end = performance.now();
    const key = label ?? '';
    const start = this.pending.get(key);
    if (start === undefined) {
      throw new Error(`${this.name}.timeEnd(${label ? `"${label}"` : ''}) was called without a matching time().`);
    }
    this.pending.delete(key);
    this.record(end - start, label !== undefined ? {
      id: label
    } : undefined);
  }
}