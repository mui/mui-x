import type { RunnerTestCase } from 'vitest';
export declare const metricsGate: {
  /** Whether custom-metric recording is currently enabled for `test`. Defaults to `true`. */
  isRecordingEnabled(test: RunnerTestCase): boolean;
  /** Enable or disable custom-metric recording for `test`. */
  setRecordingEnabled(test: RunnerTestCase, enabled: boolean): void;
};