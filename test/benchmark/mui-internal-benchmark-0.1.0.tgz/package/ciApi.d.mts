/**
 * Posts `body` to the dashboard, authenticated as this CI job, and returns the response text. `what`
 * names the request in the errors it raises.
 */
export declare function postToDashboard(pathname: string, body: unknown, what: string): Promise<string>;