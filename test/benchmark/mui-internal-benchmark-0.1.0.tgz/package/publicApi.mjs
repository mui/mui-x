// What both runtimes export: the Vitest harness (`@mui/internal-benchmark`) and the page runtime
// the `benchmark` CLI measures (`@mui/internal-benchmark/page`). Each entry adds its own case API.

export { ElementTiming } from "./ElementTiming.mjs";
export { Metric } from "./metricCore.mjs";
export { ScalarMetric } from "./ScalarMetric.mjs";
export { DiscreteMetric } from "./DiscreteMetric.mjs";