declare global {
  interface Window {
    gc?: () => void;
  }
}
/**
 * Lets pending tasks finish — a previous iteration's cleanup — then collects garbage twice, the
 * second pass catching what the first freed weak references to, so no iteration pays for another's
 * allocations. Needs `--js-flags=--expose-gc`, and warns once without it.
 */
export declare function collectGarbage(): Promise<void>;