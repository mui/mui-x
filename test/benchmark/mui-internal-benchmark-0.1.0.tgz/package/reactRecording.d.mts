export interface ReactRecordingControls {
  /** Whether React render/paint recording is active right now — the synchronous gate for renders. */
  readonly active: boolean;
  /** Whether any active recording window closed without capturing a render. */
  readonly hadEmptyActiveWindow: boolean;
  /**
   * When the recording window around `time` (a `performance.now()` timestamp) began: `-Infinity`
   * if recording was active from the start, `null` if it was paused at `time`. Paint entries are
   * observed asynchronously, so they are attributed by their `paintTime` rather than by the
   * recording state at the moment the observer callback happens to fire.
   */
  activeSince(time: number): number | null;
  /** Note that a render was captured in the current window. Called by the harness from `onRender`. */
  markRendered(): void;
  /** Close the final window at the end of the iteration (validates it if recording is still active). */
  finalizeWindow(): void;
  /** Pause React render/paint recording. Throws if recording is already paused. */
  pauseReactRecording(): void;
  /** Resume React render/paint recording. Throws if recording is already active. */
  resumeReactRecording(): void;
}
/**
 * Creates the per-iteration switch that turns the harness's React render/paint recording on and
 * off. The interaction callback drives it via `pauseReactRecording`/`resumeReactRecording`; the
 * strict state machine (each throws when called in the wrong state) catches unbalanced pairs early.
 *
 * It also tracks whether each *active* window captured at least one render, so the harness can flag
 * a window that was recording but measured nothing — while leaving fully-paused (metric-only)
 * benchmarks alone.
 */
export declare function createReactRecordingControls(initiallyActive: boolean): ReactRecordingControls;