import * as React from 'react';
import type { RenderEvent, InteractionContext, BenchmarkCaseRuntime } from "./types.mjs";
interface PerformanceElementTiming extends PerformanceEntry {
  readonly entryType: 'element';
  readonly paintTime: DOMHighResTimeStamp;
  readonly identifier: string;
}
export type BenchmarkInteraction = (ctx: InteractionContext) => Promise<void> | void;
/**
 * The harness-owned paint metric: the default sentinel is the base series (`bench:paint`) and named
 * `elementtiming` markers are sub-series (`bench:paint#grid-header`, …).
 */
export declare const PAINT_METRIC_NAME = "bench:paint";
/** How the harness's time metrics are formatted. */
export declare const MILLISECONDS: Intl.NumberFormatOptions;
export interface CaseOptions {
  afterEach?: () => Promise<void> | void;
  /**
   * Start each iteration with React render/paint recording paused. The interaction callback then
   * calls `resumeReactRecording()` at the point it cares about — useful to exclude the mount and
   * measure only the renders/paint of a later interaction. Defaults to `false` (mount recorded).
   */
  reactRecordingPaused?: boolean;
}
/** The Vitest `benchmark()`'s options. */
export interface BenchmarkOptions extends CaseOptions {
  runs?: number;
  warmupRuns?: number;
}
/** Splits `benchmark()`-style arguments, where the interaction may be left out. */
export declare function splitCaseArgs<Options extends object>(interactionOrOptions: BenchmarkInteraction | Options | undefined, maybeOptions: Options | undefined): {
  interaction: BenchmarkInteraction | undefined;
  options: Options | undefined;
};
interface ElementTimingWaiter {
  elementEntries: PerformanceElementTiming[];
  waitForElementTiming: (identifier: string, timeout?: number) => Promise<void>;
  disconnect: () => void;
}
export declare function createElementTimingWaiter(): ElementTimingWaiter;
interface CreateCaseRuntimeOptions {
  /**
   * Produces the case to mount. Measurement passes a renderFn already wrapped in `<BenchProfiler>`
   * to collect render events; profiling passes the case bare so the React Profiler overhead stays
   * out of the hand-captured DevTools trace.
   */
  renderFn: () => React.ReactElement;
  interaction?: BenchmarkInteraction;
  /**
   * Context handed to the interaction callback. The driver assembles it: measurement supplies the
   * real React recording controls, profiling supplies no-ops since the user drives DevTools by hand.
   */
  context: InteractionContext;
  onUncaughtError?: (error: unknown) => void;
}
export declare function createCaseRuntime({
  renderFn,
  interaction,
  context,
  onUncaughtError
}: CreateCaseRuntimeOptions): BenchmarkCaseRuntime;
export interface PaintTiming {
  /** The `elementtiming` identifier; `undefined` for the harness's `default` sentinel. */
  id: string | undefined;
  /** `performance.now()` when the iteration started, before mounting. */
  start: number;
  /** The element's `paintTime`. */
  end: number;
}
export interface MeasuredIteration {
  /** Renders captured while React recording was active. */
  renders: RenderEvent[];
  /** Element paints that happened while React recording was active. */
  paints: PaintTiming[];
}
/**
 * Mounts, interacts with and unmounts a case once. Records nothing itself: renders and paints are
 * returned, and the driver decides whether they count (they don't during warmup) and where they go.
 *
 * Throws what a render throws, and throws when React recording was active but captured no renders.
 */
export declare function measureIteration(renderFn: () => React.ReactElement, interaction: BenchmarkInteraction | undefined, options: CaseOptions | undefined, driver: Pick<InteractionContext, 'cdp'>): Promise<MeasuredIteration>;
export {};