import { z } from 'zod/v4';
/**
 * Creates a CI report upload schema for a specific report type: the envelope every report type
 * shares (commit, repository, branch, pull request) around its `report`. Kept apart from
 * `ciReport.ts`, which runs git, so the browser-safe run report schema can build on it.
 */
export declare function ciReportUploadSchema<ReportSchema extends z.ZodType>(type: string, version: number, reportSchema: ReportSchema): z.ZodObject<{
  version: z.ZodLiteral<number>;
  timestamp: z.ZodNumber;
  commitSha: z.ZodString;
  repo: z.ZodString;
  reportType: z.ZodLiteral<string>;
  prNumber: z.ZodOptional<z.ZodNumber>;
  branch: z.ZodString;
  commitTimestamp: z.ZodOptional<z.ZodNumber>;
  report: ReportSchema;
}, z.core.$strip>;