import type { Change, Interval, Severity } from "./analyzeRun.mjs";
import type { BenchmarkRunReport, RunBenchmark } from "./schema.mjs";
/**
 * A run's conclusions as plain data, for a program to read rather than a person: what the tables,
 * the pull request comment and the dashboard show, without the raw samples behind it.
 */
export interface RunSummary {
  /** How long the whole run took, when the report says. */
  durationMs?: number;
  /** The changes for the worse that fail the check, as the comment lists them. */
  regressions: Array<{
    benchmark: string;
    metric: string;
    relative: Interval;
  }>;
  benchmarks: BenchmarkSummary[];
}
export interface BenchmarkSummary {
  name: string;
  file: string;
  kind: RunBenchmark['kind'];
  /** Rounds measured; absent for a benchmark that failed. */
  rounds?: number;
  timedOut?: boolean;
  durationMs?: number;
  error?: string;
  metrics: Array<{
    metric: string;
    /** Per variant, the median of its samples. */
    medians: Record<string, number>;
    comparisons: Array<{
      subject: string;
      against: string;
      change: Change;
      severity: Severity;
      /** Whether the change is for the better past the alarm's band. */
      improved: boolean;
      /** `subject − against`, in the metric's unit. */
      absolute: Interval;
      /** The same, as a percentage of `against`. */
      relative: Interval;
    }>;
  }>;
}
export declare function summarizeRun(report: BenchmarkRunReport): RunSummary;