import { analyzeRun, findRegressions } from "./analyzeRun.mjs";

/**
 * A run's conclusions as plain data, for a program to read rather than a person: what the tables,
 * the pull request comment and the dashboard show, without the raw samples behind it.
 */

export function summarizeRun(report) {
  const analyses = analyzeRun(report);
  return {
    durationMs: report.durationMs,
    regressions: findRegressions(analyses).map(({
      benchmark,
      metric,
      comparison
    }) => ({
      benchmark,
      metric,
      relative: comparison.relative
    })),
    benchmarks: analyses.map(({
      benchmark,
      metrics
    }) => {
      const [reference] = benchmark.variants;
      return {
        name: benchmark.name,
        file: benchmark.file,
        kind: benchmark.kind,
        rounds: Object.values(benchmark.samples?.[reference] ?? {})[0]?.length,
        timedOut: benchmark.sampling?.timedOut,
        durationMs: benchmark.durationMs,
        error: benchmark.error,
        metrics: metrics.map(({
          metric,
          variants,
          comparisons
        }) => ({
          metric,
          medians: Object.fromEntries(Object.entries(variants).map(([variant, summary]) => [variant, summary.median])),
          comparisons: comparisons.map(({
            subject,
            against,
            change,
            severity,
            improved,
            absolute,
            relative
          }) => ({
            subject,
            against,
            change,
            severity,
            improved,
            absolute,
            relative
          }))
        }))
      };
    })
  };
}