import type { BenchmarkAnalysis, Change, Interval, AlarmedChange, MetricComparison } from "./analyzeRun.mjs";
import type { RunBenchmark, RunMetricDefinition } from "./schema.mjs";
/** A value in its metric's own format — `12.3 ms`, `4`. */
export declare function formatValue(value: number, definition: RunMetricDefinition): string;
/** Both bounds signed, so the direction of a difference reads without the verdict beside it. */
export declare function formatPercent(interval: Interval): string;
/**
 * The color a renderer draws the eye with; a `Severity` is one too. `faintSuccess` is `success`
 * without the emphasis: it marks a change for the better that is too small to list.
 */
export type Tone = 'error' | 'warning' | 'success' | 'faintSuccess' | 'none';
/**
 * The color a comparison draws the eye with: `error` for a regression that fails the check,
 * `warning` for any other change for the worse, `success` for an improvement — on an alarmed metric
 * only past its band, as the pull request comment lists them — `faintSuccess` for any other change
 * for the better, and `none` otherwise. A `compare()`'s variants have no band, so any of them
 * confirmed better is an improvement.
 */
export declare function changeTone({
  alarm,
  change,
  severity,
  improved
}: MetricComparison): Tone;
/**
 * The color a comparison's precision draws the eye with: `error` when a regression the alarm would
 * raise — one past its `error` band — could hide in the interval, `none` otherwise.
 */
export declare function precisionTone({
  alarm,
  precision
}: MetricComparison): Tone;
/** A comparison's precision as it reads: `±1.4%`, or `±0.5` for a discrete metric. */
export declare function formatPrecision(comparison: MetricComparison, definition: RunMetricDefinition): string;
/**
 * What lies behind a precision: the per-round noise, and how many rounds would resolve the alarm's
 * `error` band — `±2.0% per round · about 2 rounds resolve ±5%`.
 */
export declare function formatPrecisionDetail(comparison: MetricComparison, definition: RunMetricDefinition): string;
/** How a change reads: `better`, `worse`, `no change detected`, `unchanged`. */
export declare function formatChange(change: Change): string;
/**
 * A comparison as one phrase: `worse +2.7% – +6.8%`, `no change detected -1.2% – +0.9%`,
 * `unchanged`.
 */
export declare function formatComparison(comparison: MetricComparison): string;
/** What a comparison column is headed: `Δ vs baseline` for a build, `theirs vs ours` for a variant. */
export declare function formatComparisonLabel(benchmark: RunBenchmark, {
  subject,
  against
}: Pick<MetricComparison, 'subject' | 'against'>): string;
export interface BenchmarkTableColumn {
  header: string;
  /**
   * `value` columns hold numbers, `comparison` columns a formatted comparison, `precision` columns
   * how precisely that comparison was pinned down.
   */
  kind: 'label' | 'value' | 'comparison' | 'precision';
  /** For a `comparison` or `precision` column: which of a row's `comparisons` it shows. */
  comparison?: number;
}
export interface BenchmarkTableRow {
  metric: string;
  definition: RunMetricDefinition;
  cells: string[];
  /** The comparisons behind the row's `comparison` cells, in column order. */
  comparisons: MetricComparison[];
}
/**
 * A benchmark's results as one table, for every renderer of it: per metric, each variant's median
 * and each comparison, and with `precision`, how precisely each comparison was pinned down.
 */
export declare function benchmarkTable({
  benchmark,
  metrics
}: BenchmarkAnalysis, {
  precision
}?: {
  precision?: boolean;
}): {
  columns: BenchmarkTableColumn[];
  rows: BenchmarkTableRow[];
};
/** A duration at a glance: `850ms`, `42s`, `3m 05s`, `1h 02m`. */
export declare function formatDuration(durationMs: number): string;
/** Rounds, with those past the sample size apart: `50 rounds`, `50 + 23 rounds`. */
export declare function formatRoundCount(rounds: number, sampleSize: number): string;
/**
 * How many rounds a benchmark ran, how long it took, and whether sampling resolved: `50 rounds`,
 * `50 + 23 rounds · 1m 12s` past the sample size, `50 + 312 rounds · 3m 04s · timed out`. `null`
 * for a benchmark that measured nothing. Without `timedOut`, the timeout is left for the caller to
 * show on its own.
 */
export declare function formatRounds(benchmark: RunBenchmark, {
  timedOut
}?: {
  timedOut?: boolean;
}): string | null;
/**
 * The line a run is summed up in: how many benchmarks measured, regressed, timed out and failed, and
 * how long the run took when the report says.
 */
export declare function formatRunSummary(analyses: BenchmarkAnalysis[], regressions: AlarmedChange[], durationMs?: number): string;
/** How to read a run's numbers, under every rendering of it. */
export declare function runReportFootnote(): string;