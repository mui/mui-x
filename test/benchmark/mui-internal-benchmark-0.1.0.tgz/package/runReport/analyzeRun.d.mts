import type { BenchmarkRunReport, RunBenchmark, RunMetricAlarm, RunMetricDefinition } from "./schema.mjs";
/**
 * The one analysis of a run report, shared by the runner's table, the pull request comment and the
 * dashboard, so they cannot disagree about what a run found.
 *
 * Variants are compared on paired differences: each round measured every variant once, so the
 * per-round difference cancels whatever the machine was doing during that round, and its
 * confidence interval is far tighter than one computed from two independent sets of samples.
 *
 * Every interval is 99%, a fixed level, so a run's cost doesn't grow with how many benchmarks it
 * holds. What keeps a run of unchanged code from alarming is mostly the alarm's bands, which the
 * interval's near end has to reach.
 */
export interface Interval {
  low: number;
  high: number;
}
export interface SampleSummary {
  count: number;
  median: number;
}
/**
 * Which way a resolved change went, given the metric's direction; `undetected` (shown as "no change
 * detected") if it did not resolve; `unchanged` if every round measured the same on both sides, a
 * render count, say.
 */
export type Change = 'better' | 'worse' | 'undetected' | 'unchanged';
/** Whether a change raises its alarm. */
export type Severity = 'error' | 'none';
export interface MetricComparison {
  /** The variant the difference is about. */
  subject: string;
  /** The variant it is measured against. */
  against: string;
  /**
   * The alarm a change answers to: the metric's, with the benchmark's own merged over it, on a
   * `baseline` benchmark; `null` where no change can raise one — a metric without an alarm, one the
   * benchmark turned off, or a `compare()`, whose variants differ on purpose.
   */
  alarm: RunMetricAlarm | null;
  /** `subject − against`, in the metric's unit: confidence interval of the mean difference. */
  absolute: Interval;
  /** The same, as a percentage of `against`'s mean. */
  relative: Interval;
  /**
   * How much the difference varies from round to round: the standard deviation of the per-round
   * differences, as a percentage of `against`'s mean. A property of the benchmark rather than of how
   * long it sampled; 0 with fewer than 2 rounds.
   */
  noise: number;
  /**
   * The smallest change the run could still have missed: the interval's half-width, in the alarm's
   * units — a fraction for a scalar metric, a count for a discrete one.
   */
  precision: number;
  /**
   * Whether more rounds could still change what the alarm says: settled once the interval lies
   * wholly on one side of the alarm's `error` band on the worse side (of zero, without a band). An
   * improvement can't alarm, so the better side never keeps a run going, and nothing does where
   * nothing can alarm.
   */
  settled: boolean;
  change: Change;
  severity: Severity;
  /**
   * Whether the change is for the better by at least the alarm's `error` band, judged by the interval
   * bound nearest zero, as `severity` is on the worse side; without a band, any confirmed change for
   * the better. Always false where nothing can alarm.
   */
  improved: boolean;
}
export interface MetricAnalysis {
  metric: string;
  definition: RunMetricDefinition;
  variants: Record<string, SampleSummary>;
  comparisons: MetricComparison[];
}
export interface BenchmarkAnalysis {
  benchmark: RunBenchmark;
  /** Empty for a benchmark that failed. */
  metrics: MetricAnalysis[];
}
/** The confidence level of every interval. */
export declare const CONFIDENCE = 0.99;
/**
 * The `error` band of a scalar metric's alarm that sets none: a change has to be confidently 5%
 * worse to alarm, and sampling settles against 5%. A discrete metric's alarm without a band alarms
 * on any confirmed change in its count.
 */
export declare const DEFAULT_ERROR_BAND = 0.05;
/** The two-sided critical value of Student's t at a confidence level, 99% by default. */
export declare function tCritical(degreesOfFreedom: number, confidence?: number): number;
export interface CompareSamplesOptions {
  /**
   * The alarm a change answers to. Defaults to the metric's; `null` where no change can raise one,
   * such as between the variants of a `compare()`, which differ on purpose.
   */
  alarm?: RunMetricAlarm | null;
}
export declare function compareSamples(subject: {
  name: string;
  values: number[];
}, against: {
  name: string;
  values: number[];
}, definition: RunMetricDefinition, {
  alarm: given
}?: CompareSamplesOptions): MetricComparison;
export type MetricComparisons = Omit<MetricAnalysis, 'variants'>;
/**
 * Compares one benchmark's variants, its metrics described by `metrics` (a report's, or a run's so
 * far). The comparisons alone, which is all deciding whether to keep sampling needs.
 */
export declare function compareBenchmark(metrics: Record<string, RunMetricDefinition>, benchmark: RunBenchmark): {
  metrics: MetricComparisons[];
};
/** Analyses one benchmark: its comparisons, and a summary of each variant's samples. */
export declare function analyzeBenchmark(metrics: Record<string, RunMetricDefinition>, benchmark: RunBenchmark): BenchmarkAnalysis;
export declare function analyzeRun(report: BenchmarkRunReport): BenchmarkAnalysis[];
/** A comparison that can raise an alarm, with the benchmark and metric it belongs to. */
export interface AlarmedChange {
  benchmark: string;
  metric: string;
  comparison: MetricComparison;
}
/**
 * Whether a change says something is wrong with the code under test: an alarmed metric's change
 * for the worse, past its `error` band.
 */
export declare function isRegression(comparison: MetricComparison): boolean;
/**
 * Whether a change is one for the better on an alarmed metric, past its `error` band: what the code
 * under test sped up.
 */
export declare function isImprovement(comparison: MetricComparison): boolean;
/** Every regression in a run, with the benchmark and metric it belongs to. */
export declare function findRegressions(analyses: BenchmarkAnalysis[]): AlarmedChange[];