import { z } from 'zod/v4';
/**
 * The report the `benchmark` CLI produces, uploads and the dashboard reads: version 2 of the `benchmark`
 * report, which the Vitest reporter uploads as version 1. A repository uploads one or the other, and
 * the dashboard reads each by its version.
 *
 * It holds raw samples rather than conclusions: every variant of a benchmark is sampled once per
 * round, and index `i` of every sample array is round `i`, so any statistic — paired differences
 * included — can be computed from the report later, by whichever reader needs it, without running
 * the benchmarks again. `analyzeRun` is the one analysis the runner and the dashboard share.
 *
 * Pure and node-free, so a browser can import it.
 */
/**
 * A metric's alarm, as version 2 judges it. `error` is the smallest change that raises the alarm — a
 * relative fraction (`0.1` = 10%) for a scalar metric, an absolute count for a discrete one; without
 * it, 5% for a scalar metric and any confirmed change for a discrete one. A metric config's `warn` is for version 1 reports and
 * isn't carried here.
 */
declare const alarmSchema: z.ZodObject<{
  direction: z.ZodOptional<z.ZodEnum<{
    higherIsBetter: "higherIsBetter";
    lowerIsBetter: "lowerIsBetter";
  }>>;
  error: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
declare const metricDefinitionSchema: z.ZodObject<{
  kind: z.ZodEnum<{
    discrete: "discrete";
    scalar: "scalar";
  }>;
  format: z.ZodOptional<z.ZodCustom<Intl.NumberFormatOptions, Intl.NumberFormatOptions>>;
  alarm: z.ZodOptional<z.ZodObject<{
    direction: z.ZodOptional<z.ZodEnum<{
      higherIsBetter: "higherIsBetter";
      lowerIsBetter: "lowerIsBetter";
    }>>;
    error: z.ZodOptional<z.ZodNumber>;
  }, z.core.$strip>>;
}, z.core.$strip>;
declare const benchmarkSchema: z.ZodObject<{
  name: z.ZodString;
  file: z.ZodString;
  kind: z.ZodEnum<{
    baseline: "baseline";
    compare: "compare";
  }>;
  variants: z.ZodArray<z.ZodString>;
  samples: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodArray<z.ZodNumber>>>>;
  alarms: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
    direction: z.ZodOptional<z.ZodEnum<{
      higherIsBetter: "higherIsBetter";
      lowerIsBetter: "lowerIsBetter";
    }>>;
    error: z.ZodOptional<z.ZodNumber>;
  }, z.core.$strip>, z.ZodLiteral<false>]>>>;
  sampling: z.ZodOptional<z.ZodObject<{
    sampleSize: z.ZodNumber;
    timedOut: z.ZodBoolean;
  }, z.core.$strip>>;
  durationMs: z.ZodOptional<z.ZodNumber>;
  error: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const benchmarkRunReportSchema: z.ZodObject<{
  version: z.ZodLiteral<2>;
  generatedAt: z.ZodString;
  durationMs: z.ZodOptional<z.ZodNumber>;
  head: z.ZodObject<{
    sha: z.ZodString;
    branch: z.ZodOptional<z.ZodString>;
  }, z.core.$strip>;
  selection: z.ZodOptional<z.ZodObject<{
    filters: z.ZodArray<z.ZodString>;
    testNamePattern: z.ZodOptional<z.ZodString>;
  }, z.core.$strip>>;
  environment: z.ZodObject<{
    browser: z.ZodString;
    platform: z.ZodString;
    arch: z.ZodString;
    launchArgs: z.ZodArray<z.ZodString>;
  }, z.core.$strip>;
  builds: z.ZodRecord<z.ZodString, z.ZodObject<{
    sha: z.ZodOptional<z.ZodString>;
    label: z.ZodString;
  }, z.core.$strip>>;
  metrics: z.ZodRecord<z.ZodString, z.ZodObject<{
    kind: z.ZodEnum<{
      discrete: "discrete";
      scalar: "scalar";
    }>;
    format: z.ZodOptional<z.ZodCustom<Intl.NumberFormatOptions, Intl.NumberFormatOptions>>;
    alarm: z.ZodOptional<z.ZodObject<{
      direction: z.ZodOptional<z.ZodEnum<{
        higherIsBetter: "higherIsBetter";
        lowerIsBetter: "lowerIsBetter";
      }>>;
      error: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
  }, z.core.$strip>>;
  benchmarks: z.ZodArray<z.ZodObject<{
    name: z.ZodString;
    file: z.ZodString;
    kind: z.ZodEnum<{
      baseline: "baseline";
      compare: "compare";
    }>;
    variants: z.ZodArray<z.ZodString>;
    samples: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodArray<z.ZodNumber>>>>;
    alarms: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
      direction: z.ZodOptional<z.ZodEnum<{
        higherIsBetter: "higherIsBetter";
        lowerIsBetter: "lowerIsBetter";
      }>>;
      error: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>, z.ZodLiteral<false>]>>>;
    sampling: z.ZodOptional<z.ZodObject<{
      sampleSize: z.ZodNumber;
      timedOut: z.ZodBoolean;
    }, z.core.$strip>>;
    durationMs: z.ZodOptional<z.ZodNumber>;
    error: z.ZodOptional<z.ZodString>;
  }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * The version 2 `benchmark` upload, which the dashboard stores as the commit's `benchmark.json`: the
 * envelope every CI report shares around this report, plus the timeline it goes into.
 */
export declare const benchmarkRunUploadSchema: z.ZodObject<{
  version: z.ZodLiteral<number>;
  timestamp: z.ZodNumber;
  commitSha: z.ZodString;
  repo: z.ZodString;
  reportType: z.ZodLiteral<string>;
  prNumber: z.ZodOptional<z.ZodNumber>;
  branch: z.ZodString;
  commitTimestamp: z.ZodOptional<z.ZodNumber>;
  report: z.ZodObject<{
    version: z.ZodLiteral<2>;
    generatedAt: z.ZodString;
    durationMs: z.ZodOptional<z.ZodNumber>;
    head: z.ZodObject<{
      sha: z.ZodString;
      branch: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    selection: z.ZodOptional<z.ZodObject<{
      filters: z.ZodArray<z.ZodString>;
      testNamePattern: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    environment: z.ZodObject<{
      browser: z.ZodString;
      platform: z.ZodString;
      arch: z.ZodString;
      launchArgs: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    builds: z.ZodRecord<z.ZodString, z.ZodObject<{
      sha: z.ZodOptional<z.ZodString>;
      label: z.ZodString;
    }, z.core.$strip>>;
    metrics: z.ZodRecord<z.ZodString, z.ZodObject<{
      kind: z.ZodEnum<{
        discrete: "discrete";
        scalar: "scalar";
      }>;
      format: z.ZodOptional<z.ZodCustom<Intl.NumberFormatOptions, Intl.NumberFormatOptions>>;
      alarm: z.ZodOptional<z.ZodObject<{
        direction: z.ZodOptional<z.ZodEnum<{
          higherIsBetter: "higherIsBetter";
          lowerIsBetter: "lowerIsBetter";
        }>>;
        error: z.ZodOptional<z.ZodNumber>;
      }, z.core.$strip>>;
    }, z.core.$strip>>;
    benchmarks: z.ZodArray<z.ZodObject<{
      name: z.ZodString;
      file: z.ZodString;
      kind: z.ZodEnum<{
        baseline: "baseline";
        compare: "compare";
      }>;
      variants: z.ZodArray<z.ZodString>;
      samples: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodArray<z.ZodNumber>>>>;
      alarms: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
        direction: z.ZodOptional<z.ZodEnum<{
          higherIsBetter: "higherIsBetter";
          lowerIsBetter: "lowerIsBetter";
        }>>;
        error: z.ZodOptional<z.ZodNumber>;
      }, z.core.$strip>, z.ZodLiteral<false>]>>>;
      sampling: z.ZodOptional<z.ZodObject<{
        sampleSize: z.ZodNumber;
        timedOut: z.ZodBoolean;
      }, z.core.$strip>>;
      durationMs: z.ZodOptional<z.ZodNumber>;
      error: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
  }, z.core.$strip>;
  timeline: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type BenchmarkRunReport = z.infer<typeof benchmarkRunReportSchema>;
export type BenchmarkRunUpload = z.infer<typeof benchmarkRunUploadSchema>;
export type RunMetricDefinition = z.infer<typeof metricDefinitionSchema>;
export type RunMetricAlarm = z.infer<typeof alarmSchema>;
export type RunBenchmark = z.infer<typeof benchmarkSchema>;
export {};