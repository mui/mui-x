import { CONFIDENCE, tCritical } from "./analyzeRun.mjs";
/**
 * How a run report's numbers read, for every renderer of one: the terminal table, the pull request
 * comment and the dashboard show the same run, so they format it the same way.
 */

const DEFAULT_SCALAR_FORMAT = {
  maximumFractionDigits: 2
};
const DEFAULT_DISCRETE_FORMAT = {
  maximumFractionDigits: 1
};

// Constructing a formatter is the expensive part, and a table formats every cell.
const formatters = new Map();
function formatterFor(options) {
  const key = JSON.stringify(options);
  let formatter = formatters.get(key);
  if (!formatter) {
    formatter = new Intl.NumberFormat('en-US', options);
    formatters.set(key, formatter);
  }
  return formatter;
}

/** A value in its metric's own format — `12.3 ms`, `4`. */
export function formatValue(value, definition) {
  const options = definition.format ?? (definition.kind === 'discrete' ? DEFAULT_DISCRETE_FORMAT : DEFAULT_SCALAR_FORMAT);
  return formatterFor(options).format(value);
}

/** Both bounds signed, so the direction of a difference reads without the verdict beside it. */
export function formatPercent(interval) {
  const signed = value => `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`;
  return `${signed(interval.low)} – ${signed(interval.high)}`;
}

/**
 * The color a renderer draws the eye with; a `Severity` is one too. `faintSuccess` is `success`
 * without the emphasis: it marks a change for the better that is too small to list.
 */

/**
 * The color a comparison draws the eye with: `error` for a regression that fails the check,
 * `warning` for any other change for the worse, `success` for an improvement — on an alarmed metric
 * only past its band, as the pull request comment lists them — `faintSuccess` for any other change
 * for the better, and `none` otherwise. A `compare()`'s variants have no band, so any of them
 * confirmed better is an improvement.
 */
export function changeTone({
  alarm,
  change,
  severity,
  improved
}) {
  if (severity === 'error') {
    return 'error';
  }
  if (change === 'worse') {
    return 'warning';
  }
  if (change !== 'better') {
    return 'none';
  }
  return improved || alarm === null ? 'success' : 'faintSuccess';
}

// Rounds past which the t-distribution is the normal one, for estimating how many a run needs.
const MANY_ROUNDS = 1000;

/**
 * The color a comparison's precision draws the eye with: `error` when a regression the alarm would
 * raise — one past its `error` band — could hide in the interval, `none` otherwise.
 */
export function precisionTone({
  alarm,
  precision
}) {
  return alarm?.error !== undefined && precision >= alarm.error ? 'error' : 'none';
}

/** A comparison's precision as it reads: `±1.4%`, or `±0.5` for a discrete metric. */
export function formatPrecision(comparison, definition) {
  return definition.kind === 'discrete' ? `±${comparison.precision.toFixed(1)}` : `±${(comparison.precision * 100).toFixed(1)}%`;
}

/**
 * What lies behind a precision: the per-round noise, and how many rounds would resolve the alarm's
 * `error` band — `±2.0% per round · about 2 rounds resolve ±5%`.
 */
export function formatPrecisionDetail(comparison, definition) {
  const noise = `±${comparison.noise.toFixed(1)}% per round`;
  const band = comparison.alarm?.error;
  if (definition.kind === 'discrete' || !band) {
    return noise;
  }
  // Rounds for a half-width of the band: (z × noise / band)².
  const z = tCritical(MANY_ROUNDS);
  const rounds = Math.ceil((z * comparison.noise / (band * 100)) ** 2);
  return `${noise} · about ${rounds} rounds resolve ±${formatterFor(DEFAULT_SCALAR_FORMAT).format(band * 100)}%`;
}

/** How a change reads: `better`, `worse`, `no change detected`, `unchanged`. */
export function formatChange(change) {
  return change === 'undetected' ? 'no change detected' : change;
}

/**
 * A comparison as one phrase: `worse +2.7% – +6.8%`, `no change detected -1.2% – +0.9%`,
 * `unchanged`.
 */
export function formatComparison(comparison) {
  const label = formatChange(comparison.change);
  return comparison.change === 'unchanged' ? label : `${label} ${formatPercent(comparison.relative)}`;
}

/** What a comparison column is headed: `Δ vs baseline` for a build, `theirs vs ours` for a variant. */
export function formatComparisonLabel(benchmark, {
  subject,
  against
}) {
  return benchmark.kind === 'baseline' ? `Δ vs ${against}` : `${subject} vs ${against}`;
}
/**
 * A benchmark's results as one table, for every renderer of it: per metric, each variant's median
 * and each comparison, and with `precision`, how precisely each comparison was pinned down.
 */
export function benchmarkTable({
  benchmark,
  metrics
}, {
  precision = false
} = {}) {
  // Builds read old to new, the baseline first, like a diff; compared cases keep the reference
  // first, as the comparison columns measure against it.
  const columnOrder = benchmark.kind === 'baseline' ? [...benchmark.variants].reverse() : benchmark.variants;
  const comparisonHeaders = (metrics[0]?.comparisons ?? []).map(comparison => formatComparisonLabel(benchmark, comparison));
  const columns = [{
    header: 'Metric',
    kind: 'label'
  }, ...columnOrder.map(variant => ({
    header: variant,
    kind: 'value'
  })), ...comparisonHeaders.map((header, comparison) => ({
    header,
    kind: 'comparison',
    comparison
  })), ...(precision ? comparisonHeaders.map((header, comparison) => ({
    header: comparisonHeaders.length === 1 ? 'Precision' : `${header} ±`,
    kind: 'precision',
    comparison
  })) : [])];
  const rows = metrics.map(({
    metric,
    definition,
    variants,
    comparisons
  }) => ({
    metric,
    definition,
    comparisons,
    cells: [metric, ...columnOrder.map(variant => formatValue(variants[variant].median, definition)), ...comparisons.map(formatComparison), ...(precision ? comparisons.map(comparison => formatPrecision(comparison, definition)) : [])]
  }));
  return {
    columns,
    rows
  };
}

/** A duration at a glance: `850ms`, `42s`, `3m 05s`, `1h 02m`. */
export function formatDuration(durationMs) {
  if (durationMs < 1000) {
    return `${Math.round(durationMs)}ms`;
  }
  const seconds = Math.round(durationMs / 1000);
  if (seconds < 60) {
    return `${seconds}s`;
  }
  const minutes = Math.floor(seconds / 60);
  const twoDigits = value => String(value).padStart(2, '0');
  return minutes < 60 ? `${minutes}m ${twoDigits(seconds % 60)}s` : `${Math.floor(minutes / 60)}h ${twoDigits(minutes % 60)}m`;
}

/** Rounds, with those past the sample size apart: `50 rounds`, `50 + 23 rounds`. */
export function formatRoundCount(rounds, sampleSize) {
  return rounds > sampleSize ? `${sampleSize} + ${rounds - sampleSize} rounds` : `${rounds} rounds`;
}

/**
 * How many rounds a benchmark ran, how long it took, and whether sampling resolved: `50 rounds`,
 * `50 + 23 rounds · 1m 12s` past the sample size, `50 + 312 rounds · 3m 04s · timed out`. `null`
 * for a benchmark that measured nothing. Without `timedOut`, the timeout is left for the caller to
 * show on its own.
 */
export function formatRounds(benchmark, {
  timedOut = true
} = {}) {
  const [reference] = benchmark.variants;
  const rounds = Object.values(benchmark.samples?.[reference] ?? {})[0]?.length;
  if (rounds === undefined) {
    return null;
  }
  return [formatRoundCount(rounds, benchmark.sampling?.sampleSize ?? rounds), benchmark.durationMs === undefined ? null : formatDuration(benchmark.durationMs), timedOut && benchmark.sampling?.timedOut ? 'timed out' : null].filter(Boolean).join(' · ');
}

/**
 * The line a run is summed up in: how many benchmarks measured, regressed, timed out and failed, and
 * how long the run took when the report says.
 */
export function formatRunSummary(analyses, regressions, durationMs) {
  const measured = analyses.filter(analysis => !analysis.benchmark.error).length;
  const failed = analyses.length - measured;
  const regressed = new Set(regressions.map(regression => regression.benchmark)).size;
  const timedOut = analyses.filter(analysis => analysis.benchmark.sampling?.timedOut).length;
  return [`${measured} benchmark${measured === 1 ? '' : 's'} measured`, regressed > 0 ? `${regressed} with regressions` : 'no regressions', timedOut > 0 ? `${timedOut} timed out` : null, failed > 0 ? `${failed} failed` : null, durationMs === undefined ? null : `ran ${formatDuration(durationMs)}`].filter(Boolean).join(' · ');
}

/** How to read a run's numbers, under every rendering of it. */
export function runReportFootnote() {
  return `Medians; Δ is the confidence interval of the paired per-round difference (${formatConfidence(CONFIDENCE)}).`;
}
function formatConfidence(fraction) {
  return `${formatterFor(DEFAULT_SCALAR_FORMAT).format(fraction * 100)}%`;
}