interface SyncPrCommentResult {
  success: boolean;
  skipped?: boolean;
}
/** Asks the dashboard to regenerate the pull request comment for `repo`. */
export declare function syncPrComment(repo: string): Promise<SyncPrCommentResult>;
export {};