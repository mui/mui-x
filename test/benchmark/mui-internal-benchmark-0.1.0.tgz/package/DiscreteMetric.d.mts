import { Metric } from "./metricCore.mjs";
import type { MetricConfig, MetricKind } from "./types.mjs";
/**
 * A discrete count of events or occurrences, whose alarm bands are absolute count deltas.
 * Formatted as a whole number by default.
 *
 * ```ts
 * const clicks = new DiscreteMetric({ name: 'button_clicks' });
 * clicks.record(countClicks());
 * ```
 */
export declare class DiscreteMetric extends Metric {
  readonly kind: MetricKind;
  constructor(config: MetricConfig | string);
}