/** Creates a temporary directory and removes it when the current test ends, even if it throws. */
export declare function makeTempDir(): Promise<string>;