/** Escapes text for use in HTML content or a double-quoted attribute. */
export declare function escapeHtml(text: string): string;