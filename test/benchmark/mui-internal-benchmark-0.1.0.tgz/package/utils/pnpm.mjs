import { $ } from 'execa';

/** A publishable workspace package, as `pnpm ls` reports it. */

/**
 * The publishable workspace packages of `cwd`: those pnpm lists that are not private and have the
 * name and version publishing requires.
 */
export async function listPublishablePackages(cwd) {
  const result = await $({
    cwd
  })`pnpm ls -r --json --depth -1`;
  const listed = JSON.parse(result.stdout);
  return listed.flatMap(pkg => pkg.private || !pkg.name || !pkg.version ? [] : [{
    name: pkg.name,
    version: pkg.version,
    path: pkg.path
  }]);
}