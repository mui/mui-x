export interface PackedPackage {
  /** Package name from its package.json. */
  name: string;
  version: string;
  /** Absolute path to the packed `.tgz`. */
  tarball: string;
}
export interface PackRefOptions {
  /** The repository the ref lives in; also where the worktree is added from. */
  repoRoot: string;
  /** A git ref (SHA, branch, or tag) to pack. */
  ref: string;
  /** Cache root. The packed folder lands at `<outRoot>/<sha>` and is reused on the next call. */
  outRoot: string;
  /**
   * Command run in the checkout to install before building. Defaults to a frozen-lockfile
   * `pnpm install`; pass `''` to skip installing.
   */
  installCmd?: string;
  /**
   * Command run in the checkout to build before packing. Defaults to `pnpm release:build`. Part of
   * the cache key.
   */
  buildCmd?: string;
}
/**
 * Packs every public workspace package at `ref` into `<outRoot>/<sha>`, returning the packed
 * tarballs.
 *
 * The folder is cached by SHA: a later call for the same commit, built with the same `buildCmd`,
 * reuses it and skips the checkout, install and build. It is assembled in a staging folder and
 * renamed into place, so an interrupted run never leaves something that looks like a cache.
 */
export declare function packRef(options: PackRefOptions): Promise<PackedPackage[]>;
/**
 * Builds and packs the working tree into `outRoot`, naming each tarball by a hash of its bytes: an
 * unchanged build keeps its path, so an install that depends on it has nothing to redo.
 */
export declare function packWorkingTree(options: {
  /** The workspace to build and pack. */
  repoRoot: string;
  /** Directory to hold the hashed tarballs. Replaced on each call. */
  outRoot: string;
  /** Command that builds the publishable packages. Defaults to `pnpm release:build`. */
  buildCmd?: string;
}): Promise<PackedPackage[]>;