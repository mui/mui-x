/** A publishable workspace package, as `pnpm ls` reports it. */
export interface PublishablePackage {
  name: string;
  version: string;
  /** Absolute path to the package directory. */
  path: string;
}
/**
 * The publishable workspace packages of `cwd`: those pnpm lists that are not private and have the
 * name and version publishing requires.
 */
export declare function listPublishablePackages(cwd: string): Promise<PublishablePackage[]>;