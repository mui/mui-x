/** Resolves a committish to the commit it names, peeling an annotated tag to its commit. */
export declare function resolveCommit(repoRoot: string, ref: string): Promise<string>;