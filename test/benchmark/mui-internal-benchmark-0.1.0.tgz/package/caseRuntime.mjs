var _ElementTiming;
import * as React from 'react';
// React only reports render durations from its profiling build.
import * as ReactDOMClient from 'react-dom/profiling';
import * as ReactDOM from 'react-dom';
import { ElementTiming } from "./ElementTiming.mjs";
import { createReactRecordingControls } from "./reactRecording.mjs";

// Everything here runs a React case without knowing who drives it: the Vitest harness (`index.tsx`)
// and the page runtime's `reactBenchmark()` both build on it, so nothing in this module may import
// Vitest.
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * The harness-owned paint metric: the default sentinel is the base series (`bench:paint`) and named
 * `elementtiming` markers are sub-series (`bench:paint#grid-header`, …).
 */
export const PAINT_METRIC_NAME = 'bench:paint';

/** How the harness's time metrics are formatted. */
export const MILLISECONDS = {
  style: 'unit',
  unit: 'millisecond',
  maximumFractionDigits: 2
};

/** Why a case failed when React recording was active yet captured no renders. */
const EMPTY_RECORDING_MESSAGE = 'React recording was active but captured no renders. If you only measure imperative DOM ' + 'updates or custom metrics, keep recording paused (reactRecordingPaused) instead of resuming.';

/** The Vitest `benchmark()`'s options. */

/** Splits `benchmark()`-style arguments, where the interaction may be left out. */
export function splitCaseArgs(interactionOrOptions, maybeOptions) {
  return typeof interactionOrOptions === 'function' ? {
    interaction: interactionOrOptions,
    options: maybeOptions
  } : {
    interaction: undefined,
    options: interactionOrOptions ?? maybeOptions
  };
}
function BenchProfiler({
  captures,
  recording,
  children
}) {
  const onRender = React.useCallback((id, phase, actualDuration, _baseDuration, startTime) => {
    // Skip renders captured while React recording is paused (e.g. the mount when the benchmark
    // starts paused, or a span the interaction explicitly excludes).
    if (recording.active) {
      captures.push({
        id,
        phase,
        actualDuration,
        startTime
      });
      recording.markRendered();
    }
  }, [captures, recording]);
  return /*#__PURE__*/_jsx(React.Profiler, {
    id: "bench",
    onRender: onRender,
    children: children
  });
}
function supportsElementTiming() {
  return PerformanceObserver.supportedEntryTypes.includes('element');
}
// Sets up a PerformanceObserver for the Element Timing API and exposes a promise-based
// `waitForElementTiming` helper. Used by the measurement loop (which also reads `elementEntries`
// to record paint metrics) and the interactive profiling session.
export function createElementTimingWaiter() {
  const hasElementTiming = supportsElementTiming();
  const elementEntries = [];
  const elementResolvers = new Map();
  let observer = null;
  if (hasElementTiming) {
    observer = new PerformanceObserver(list => {
      for (const entry of list.getEntries()) {
        elementEntries.push(entry);
        const resolver = elementResolvers.get(entry.identifier);
        if (resolver) {
          elementResolvers.delete(entry.identifier);
          resolver();
        }
      }
    });
    observer.observe({
      type: 'element',
      buffered: false
    });
  }
  const waitForElementTiming = (identifier, timeout) => {
    if (!hasElementTiming) {
      console.warn(`waitForElementTiming("${identifier}"): Element Timing API is not supported. ` + 'Paint metrics will not be collected.');
      return Promise.resolve();
    }
    if (elementEntries.some(entry => entry.identifier === identifier)) {
      return Promise.resolve();
    }
    const {
      promise,
      resolve,
      reject
    } = Promise.withResolvers();
    const timeoutMs = timeout ?? 5000;
    const timer = timeoutMs > 0 && timeoutMs < Infinity ? setTimeout(() => {
      elementResolvers.delete(identifier);
      reject(new Error(`waitForElementTiming("${identifier}"): timed out after ${timeoutMs}ms. ` + 'Ensure the element has an `elementtiming` attribute and is visible in the viewport.'));
    }, timeoutMs) : undefined;
    elementResolvers.set(identifier, () => {
      if (timer) {
        clearTimeout(timer);
      }
      resolve();
    });
    return promise;
  };
  return {
    elementEntries,
    waitForElementTiming,
    disconnect: () => observer?.disconnect()
  };
}
export function createCaseRuntime({
  renderFn,
  interaction,
  context,
  onUncaughtError
}) {
  let root = null;
  let container = null;
  return {
    mount() {
      if (root) {
        return;
      }
      container = document.createElement('div');
      document.body.appendChild(container);
      const newRoot = ReactDOMClient.createRoot(container, {
        onUncaughtError
      });
      root = newRoot;
      ReactDOM.flushSync(() => {
        newRoot.render(/*#__PURE__*/_jsxs(React.Fragment, {
          children: [renderFn(), _ElementTiming || (_ElementTiming = /*#__PURE__*/_jsx(ElementTiming, {
            name: "default"
          }))]
        }));
      });
    },
    interact: interaction ? async () => {
      await interaction(context);
    } : undefined,
    unmount() {
      if (!root) {
        return;
      }
      root.unmount();
      container?.remove();
      root = null;
      container = null;
    },
    isMounted: () => root !== null
  };
}
/**
 * Mounts, interacts with and unmounts a case once. Records nothing itself: renders and paints are
 * returned, and the driver decides whether they count (they don't during warmup) and where they go.
 *
 * Throws what a render throws, and throws when React recording was active but captured no renders.
 */
export async function measureIteration(renderFn, interaction, options, driver) {
  // Per-iteration switch for the harness's React render/paint recording. Starts paused when
  // `reactRecordingPaused` is set; the interaction callback drives it from there.
  const recording = createReactRecordingControls(!(options?.reactRecordingPaused ?? false));
  const captures = [];
  const timing = createElementTimingWaiter();
  // Asserted rather than annotated: only the callback assigns it, which narrowing cannot see.
  let renderFailure = null;
  const runtime = createCaseRuntime({
    // Wrap the case in BenchProfiler so its renders are captured; the runtime mounts whatever
    // renderFn returns (profiling passes the case bare).
    renderFn: () => /*#__PURE__*/_jsx(BenchProfiler, {
      captures: captures,
      recording: recording,
      children: renderFn()
    }),
    interaction,
    context: {
      waitForElementTiming: timing.waitForElementTiming,
      pauseReactRecording: recording.pauseReactRecording,
      resumeReactRecording: recording.resumeReactRecording,
      ...driver
    },
    onUncaughtError: error => {
      renderFailure = {
        error
      };
    }
  });
  const iterationStart = performance.now();
  runtime.mount();
  if (renderFailure) {
    timing.disconnect();
    runtime.unmount();
    throw renderFailure.error;
  }
  await runtime.interact?.();

  // Wait for the bench sentinel paint entry (relies on the driver's timeout)
  await timing.waitForElementTiming('default', 0);

  // Close the final window so an active window that measured no renders is flagged.
  recording.finalizeWindow();
  timing.disconnect();
  runtime.unmount();
  const paints = [];
  for (const entry of timing.elementEntries) {
    // Skip paints that happened while recording was paused. Attribute by the paint's
    // `paintTime`, not by when the observer callback fired (which can lag the paint).
    const since = recording.activeSince(entry.paintTime);
    if (since === null) {
      continue;
    }
    // The default sentinel is the base series; named markers become sub-series. A paint is timed
    // from when its recording window began — the mount, or where the interaction resumed
    // recording — so a case that starts paused doesn't count the mount it chose to leave out.
    const id = entry.identifier === 'default' ? undefined : entry.identifier;
    paints.push({
      id,
      start: Math.max(iterationStart, since),
      end: entry.paintTime
    });
  }
  if (options?.afterEach) {
    await options.afterEach();
  }

  // Windows where recording never ran (e.g. a fully paused, metric-only case) are not checked.
  if (recording.hadEmptyActiveWindow) {
    throw new Error(EMPTY_RECORDING_MESSAGE);
  }
  return {
    renders: captures,
    paints
  };
}