declare module 'eslint-config-airbnb-base' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/best-practices' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/errors' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/es6' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/imports' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/node' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/strict' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/style' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb-base/rules/variables' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb/rules/react' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module 'eslint-config-airbnb/rules/react-a11y' {
  import type { Linter } from 'eslint';

  declare const config: Omit<Linter.LegacyConfig, 'extends' | 'plugins'>;
  export default config;
}

declare module '@next/eslint-plugin-next' {
  import type { Linter } from 'eslint';

  interface NextEslintPluginConfig extends Linter.LegacyConfig {
    flatConfig: {
      recommended: Linter.Config;
    };
  }

  declare const config: NextEslintPluginConfig;
  export default config;
}

declare module '@babel/plugin-transform-runtime' {
  import type { PluginItem } from '@babel/core';

  declare const plugin: PluginItem;
  export default plugin;
}

declare module '@babel/plugin-syntax-jsx' {
  import type { PluginItem } from '@babel/core';

  declare const plugin: PluginItem;
  export default plugin;
}

declare module '@babel/plugin-syntax-typescript' {
  import type { PluginItem } from '@babel/core';

  declare const plugin: PluginItem;
  export default plugin;
}

declare module 'babel-plugin-optimize-clsx' {
  import type { PluginItem } from '@babel/core';

  declare const plugin: PluginItem;
  export default plugin;
}

declare module 'babel-plugin-transform-react-remove-prop-types' {
  import type { PluginItem } from '@babel/core';

  declare const plugin: PluginItem;
  export default plugin;
}

declare module 'babel-plugin-transform-import-meta' {
  import type { PluginItem } from '@babel/core';

  declare const plugin: PluginItem;
  export default plugin;
}

declare module 'babel-plugin-transform-inline-environment-variables' {
  import type { PluginItem } from '@babel/core';

  declare const plugin: PluginItem;
  export default plugin;
}

declare module '@babel/preset-react' {
  import type { PluginItem } from '@babel/core';

  export type Options = {
    runtime: 'string';
  };

  declare const preset: PluginItem;
  export default preset;
}

declare module '@babel/preset-typescript' {
  import type { PluginItem } from '@babel/core';

  declare const preset: PluginItem;
  export default preset;
}

declare module 'stylelint-config-standard' {
  import type { Config } from 'stylelint';

  declare const configExtends: Config['extends'];
  export default configExtends;
}
declare module 'postcss-styled-syntax' {
  import type { Parser, Stringifier } from 'postcss';

  export const parse: Parser;
  export const stringify: Stringifier;
}
