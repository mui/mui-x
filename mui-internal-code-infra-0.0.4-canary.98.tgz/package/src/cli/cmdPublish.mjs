#!/usr/bin/env node

/* eslint-disable no-console */

/**
 * @typedef {import('../utils/pnpm.mjs').PublicPackage} PublicPackage
 * @typedef {import('../utils/pnpm.mjs').PublishOptions} PublishOptions
 * @typedef {import('../utils/pnpm.mjs').PublishSummaryEntry} PublishSummaryEntry
 */

import select from '@inquirer/select';
import { createActionAuth } from '@octokit/auth-action';
import { Octokit } from '@octokit/rest';
import chalk from 'chalk';
import envCI from 'env-ci';
import { $ } from 'execa';
import * as fs from 'node:fs/promises';
import * as semver from 'semver';

import { persistentAuthStrategy } from '../utils/github.mjs';
import {
  getPackagesNeedingManualPublish,
  getWorkspacePackages,
  publishPackages,
  validatePublishDependencies,
} from '../utils/pnpm.mjs';
import { getCurrentGitSha, getRepositoryInfo, remoteGitTagExists } from '../utils/git.mjs';

const isCI = envCI().isCi;

function getOctokit() {
  return new Octokit({ authStrategy: isCI ? createActionAuth : persistentAuthStrategy });
}

/**
 * @typedef {Object} Args
 * @property {boolean} dry-run Run in dry-run mode without publishing
 * @property {boolean} github-release Create a GitHub draft release after publishing
 * @property {string} tag NPM dist tag to publish to
 * @property {boolean} ci Runs in CI environment
 * @property {string} [sha] Git SHA to use for the GitHub release workflow (local only)
 * @property {string[]} [filter] Same as filtering packages with --filter in pnpm. Only publish packages matching the filter. See https://pnpm.io/filtering.
 */

/**
 * Get the version to release from the root package.json
 * @returns {Promise<string | null>} Version string
 */
async function getReleaseVersion() {
  // `--json` is required: pnpm 11 returns the raw value (e.g. `9.4.0`) for a
  // single field without it, which is not valid JSON. The flag forces quoted
  // output (`"9.4.0"`) across pnpm 9/10/11.
  const result = await $`pnpm pkg get version --json`;
  const version = JSON.parse(result.stdout.trim());
  return semver.valid(version);
}

/**
 * Parse changelog to extract content for a specific version
 * @param {string} changelogPath - Path to CHANGELOG.md
 * @param {string} version - Version to extract
 * @returns {Promise<string>} Changelog content for the version
 */
async function parseChangelog(changelogPath, version) {
  try {
    const content = await fs.readFile(changelogPath, 'utf8');
    const lines = content.split('\n');

    const startIndex = lines.findIndex(
      (line) => line.startsWith(`## ${version}`) || line.startsWith(`## v${version}`),
    );

    if (startIndex === -1) {
      throw new Error(`Version ${version} not found in changelog`);
    }

    // Skip the version header and find content start
    let contentStartIndex = startIndex + 1;

    // Skip whitespace and comment lines
    while (contentStartIndex < lines.length) {
      const line = lines[contentStartIndex].trim();
      if (line === '' || line.startsWith('<!--')) {
        contentStartIndex += 1;
      } else {
        break;
      }
    }

    // Check if first content line is a date line
    if (contentStartIndex < lines.length) {
      const line = lines[contentStartIndex].trim();
      // Remove leading/trailing underscores if present
      const cleanLine = line.replace(/^_+|_+$/g, '');
      // Try to parse as date
      if (cleanLine && !Number.isNaN(Date.parse(cleanLine))) {
        contentStartIndex += 1; // Skip date line
      }
    }

    // Find the end of this version's content (next ## header)
    let endIndex = lines.length;
    for (let i = contentStartIndex; i < lines.length; i += 1) {
      if (lines[i].startsWith('## ')) {
        endIndex = i;
        break;
      }
    }

    return lines.slice(contentStartIndex, endIndex).join('\n').trim();
  } catch (/** @type {any} */ error) {
    if (error.code === 'ENOENT') {
      throw new Error('CHANGELOG.md not found');
    }
    throw error;
  }
}

/**
 * Check if GitHub release already exists
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {string} version - Version to check
 * @returns {Promise<boolean>} True if release exists
 */
async function checkGitHubReleaseExists(owner, repo, version) {
  try {
    const octokit = getOctokit();
    await octokit.repos.getReleaseByTag({ owner, repo, tag: `v${version}` });
    return true;
  } catch (/** @type {any} */ error) {
    if (error.status === 404) {
      return false;
    }
    throw error;
  }
}

/**
 * Create and push a git tag
 * @param {string} version - Version to tag
 * @param {boolean} [dryRun=false] - Whether to run in dry-run mode
 * @returns {Promise<void>}
 */
async function createGitTag(version, dryRun = false) {
  const tagName = `v${version}`;
  // The CI smoke-test runs with a read-only token that can't push. It sets this
  // so we tolerate the push failure explicitly, instead of assuming any dry-run
  // permission error is expected.
  const isPublishTest = process.env.IS_PUBLISH_TEST === 'true';

  try {
    // Skip if the tag already exists locally. Tag creation is local and fails if it exists.
    const { stdout: existingTag } = await $`git tag -l ${tagName}`;
    if (existingTag.trim()) {
      console.log(`🏷️  Git tag ${tagName} already exists, skipping`);
      return;
    }

    await $({
      env: {
        ...process.env,
        GIT_COMMITTER_NAME: 'Code infra',
        GIT_COMMITTER_EMAIL: 'code-infra@mui.com',
      },
    })`git tag -a ${tagName} -m ${`Version ${version}`}`;

    if (dryRun) {
      // `git push --dry-run` still authenticates and needs push access. When the token
      // can push, validate it for real; when it can't, only tolerate the failure if this
      // is an explicit publish smoke-test and the error is a genuine permission denial.
      try {
        // Don't inherit stdio so stderr is captured and matchable below.
        await $`git push origin ${tagName} --dry-run`;
        console.log(`🏷️  Created git tag ${tagName} (dry-run)`);
      } catch (/** @type {any} */ pushError) {
        const message = pushError.stderr || pushError.message || '';
        if (isPublishTest && /permission|403|denied/i.test(message)) {
          console.log(`🏷️  Created git tag ${tagName} (dry-run, no push permission, skipped push)`);
          return;
        }
        throw pushError;
      }
      return;
    }
    await $({ stdio: 'inherit' })`git push origin ${tagName}`;

    console.log(`🏷️  Created and pushed git tag ${tagName}`);
  } catch (/** @type {any} */ error) {
    throw new Error(`Failed to create git tag: ${error.message}`);
  }
}

/**
 * Validate GitHub release requirements
 * @param {string} version - Version to validate
 * @returns {Promise<{changelogContent: string, version: string, repoInfo: {owner: string, repo: string}}>}
 */
async function validateGitHubRelease(version) {
  console.log('🔍 Validating GitHub release requirements...');

  const validVersion = semver.valid(version);
  if (!validVersion) {
    throw new Error(`Invalid version in root package.json: ${version}`);
  }

  // Check if CHANGELOG.md exists and parse it
  console.log(`📄 Parsing CHANGELOG.md for version ${validVersion}...`);
  const changelogContent = await parseChangelog('CHANGELOG.md', validVersion);
  console.log('✅ Found changelog content for version');

  // Get repository info
  const repoInfo = await getRepositoryInfo();
  console.log(`📂 Repository: ${repoInfo.owner}/${repoInfo.repo}`);

  console.log(`🔍 Checking if GitHub release v${validVersion} already exists...`);
  const releaseExists = await checkGitHubReleaseExists(repoInfo.owner, repoInfo.repo, validVersion);

  if (releaseExists) {
    throw new Error(`GitHub release v${validVersion} already exists`);
  }
  console.log('✅ GitHub release does not exist yet');

  return { changelogContent, repoInfo, version: validVersion };
}

/**
 * Publish packages to npm
 * @param {PublicPackage[]} packages - Packages to publish
 * @param {PublishOptions} options - Publishing options
 * @returns {Promise<PublishSummaryEntry[]>}
 */
async function publishToNpm(packages, options) {
  // Use pnpm's built-in duplicate checking - no need to check versions ourselves
  return publishPackages(packages, options);
}

/**
 * Create GitHub release after npm publishing
 * @param {string} version - Version to release
 * @param {string} changelogContent - Changelog content
 * @param {{owner: string, repo: string}} repoInfo - Repository info
 * @returns {Promise<void>}
 */
async function createRelease(version, changelogContent, repoInfo) {
  console.log('\n🚀 Creating GitHub draft release...');

  const sha = await getCurrentGitSha();

  const octokit = getOctokit();
  await octokit.repos.createRelease({
    owner: repoInfo.owner,
    repo: repoInfo.repo,
    tag_name: `v${version}`,
    target_commitish: sha,
    name: `v${version}`,
    body: changelogContent,
    draft: true,
  });

  console.log(
    `✅ Created draft release v${version} at https://github.com/${repoInfo.owner}/${repoInfo.repo}/releases`,
  );
}

export default /** @type {import('yargs').CommandModule<{}, Args>} */ ({
  command: 'publish',
  describe: 'Publish packages to npm',
  builder: (yargs) => {
    return yargs
      .parserConfiguration({ 'boolean-negation': false })
      .option('dry-run', {
        type: 'boolean',
        default: false,
        description: 'Run in dry-run mode without publishing',
      })
      .option('github-release', {
        type: 'boolean',
        default: false,
        description: 'Create a GitHub draft release after publishing',
      })
      .option('tag', {
        type: 'string',
        default: 'latest',
        description: 'NPM dist tag to publish to',
      })
      .option('ci', {
        type: 'boolean',
        description:
          'Runs in CI environment. On local environments, it triggers the GitHub publish workflow instead of publishing directly.',
      })
      .option('sha', {
        type: 'string',
        description: 'Git SHA to use for the GitHub release workflow (local only)',
      })
      .option('filter', {
        type: 'string',
        array: true,
        description:
          'Same as filtering packages with --filter in pnpm. Only publish packages matching the filter. See https://pnpm.io/filtering.',
      });
  },
  handler: async (argv) => {
    const { dryRun = false, githubRelease = false, tag = 'latest', sha, filter = [] } = argv;

    if (isCI && !argv.ci) {
      console.error(
        chalk.yellow(
          '❌ Error: CI environment detected but the "--ci" flag was not passed. Pass it explicitly to run in CI.',
        ),
      );
      process.exit(1);
    }
    argv.ci = argv.ci ?? isCI;

    if (argv.ci && sha) {
      throw new Error('The --sha option can only be used in non-CI environments');
    }

    if (dryRun) {
      console.log('🧪 Running in DRY RUN mode - no actual publishing will occur\n');
    }

    if (!argv.ci) {
      await triggerLocalGithubPublishWorkflow(argv);
      return;
    }
    // Get all packages
    console.log('🔍 Discovering all workspace packages...');

    const filteredPackages = await getWorkspacePackages({ publicOnly: true, filter });

    if (filteredPackages.length === 0) {
      console.log(
        `⚠️  No publishable packages found in workspace${filter.length > 0 ? ` matching filter "${filter.join(', ')}"` : ''}`,
      );
      return;
    }

    if (filter.length > 0) {
      console.log('🔍 Validating workspace dependencies for filtered packages...');

      const { issues } = await validatePublishDependencies(filteredPackages);

      if (issues.length > 0) {
        throw new Error(
          `Invalid dependencies structure of packages to be published -
  ${issues.join('\n  ')}
`,
          {
            cause: issues,
          },
        );
      }

      console.log('✅ All workspace dependency requirements satisfied');
    }

    // Get version from root package.json
    const version = await getReleaseVersion();

    if (!version) {
      throw new Error('No valid version found in root package.json');
    }

    // Early validation for GitHub release (before any publishing)
    let githubReleaseData = null;
    if (githubRelease) {
      console.log(`📋 Release version: ${version}`);
      githubReleaseData = await validateGitHubRelease(version);
    }

    const newPackages = await getPackagesNeedingManualPublish(filteredPackages);

    if (newPackages.length > 0) {
      const newPackageNames = newPackages.map((pkg) => pkg.name).join(', ');
      throw new Error(
        `The following packages are new and need to be published to npm manually first: ${newPackageNames}. Read more about it here: https://github.com/mui/mui-public/blob/master/packages/code-infra/README.md#adding-and-publishing-new-packages`,
      );
    }

    // Publish to npm (pnpm handles duplicate checking automatically)
    // No git checks, we'll do our own
    console.log('\n📦 Publishing packages to npm...');
    const publishedPackages = await publishToNpm(filteredPackages, {
      dryRun,
      noGitChecks: true,
      tag,
    });

    if (publishedPackages.length === 0) {
      console.log('ℹ️  No packages were published (all may already be up to date on npm)');
      console.log('\n🏁 Nothing to publish, skipping git tag and GitHub release.');
      return;
    }

    publishedPackages.forEach((pkg) => {
      console.log(`✅ Published ${pkg.name}@${pkg.version}`);
    });

    // Tag the root version when it's new. Arbitrary package publishes that don't
    // bump the root version don't create a new tag, so skip in that case.
    if (await remoteGitTagExists(`v${version}`)) {
      console.log(`ℹ️  Git tag v${version} already exists, skipping tag creation.`);
    } else {
      await createGitTag(version, dryRun);
    }

    // Create GitHub release or git tag after successful npm publishing
    if (githubRelease && githubReleaseData) {
      if (dryRun) {
        console.log('\n🚀 Would create GitHub draft release (dry-run)');
        console.log(githubReleaseData?.changelogContent);
      } else {
        await createRelease(
          githubReleaseData.version,
          githubReleaseData.changelogContent,
          githubReleaseData.repoInfo,
        );
      }
    }

    console.log('\n🏁 Publishing complete!');
  },
});

const WORKFLOW_PATH = 'workflows/publish.yml';
const PUBLISH_WORKFLOW_ID = `.github/${WORKFLOW_PATH}`;

/**
 * @param {Omit<Args, 'ci'>} opts
 */
async function triggerLocalGithubPublishWorkflow(opts) {
  console.log(`🔍 Checking if there are new packages to publish in the workspace...`);
  const newPackages = await getPackagesNeedingManualPublish(
    await getWorkspacePackages({ publicOnly: true }),
  );
  if (newPackages.length) {
    console.warn(
      `⚠️  Found new packages that should be published to npm first before triggering a release:
${newPackages.map((pkg) => `  * ${pkg.name}`).join('\n')}
Please run the command "${chalk.bold('pnpm code-infra publish-new-package')}" first to publish and configure npm.`,
    );
    return;
  }
  console.log('✅ No new packages found, proceeding...');
  const repoInfo = await getRepositoryInfo();
  console.log(`📂 Repository: ${repoInfo.owner}/${repoInfo.repo}`);
  const params = {
    owner: repoInfo.owner,
    repo: repoInfo.repo,
    workflow_id: PUBLISH_WORKFLOW_ID,
  };
  const octokit = getOctokit();

  try {
    const sha = opts.sha || (await determineGitSha(octokit, repoInfo));
    if (!sha) {
      console.error('❌🚨 No commit SHA provided, cannot proceed.');
      return;
    }

    await octokit.actions.createWorkflowDispatch({
      ...params,
      ref: 'master',
      inputs: {
        sha,
        'dry-run': opts['dry-run'] ? 'true' : 'false',
        'github-release': opts['github-release'] ? 'true' : 'false',
        'dist-tag': opts.tag,
      },
    });
    console.log(
      `🎉✅ Release created successfully! Check the status at: https://github.com/${params.owner}/${params.repo}/actions/${WORKFLOW_PATH} .`,
    );
  } catch (error) {
    const err =
      /** @type {import('@octokit/types').RequestError & {response: {data: {message: string; documentation_url: string}}}} */ (
        error
      );
    const manualTriggerUrl = `You can also trigger the workflow manually at: https://github.com/${params.owner}/${params.repo}/actions/${WORKFLOW_PATH}`;
    if (err.status === 422) {
      console.error(`❌🚫 ${err.response.data.message}\n. ${manualTriggerUrl}`);
      return;
    }
    if (err.status === 403) {
      const isAppPermissionIssue = /not accessible by integration/.exec(err.response.data.message);
      console.error(
        `❌🔒 ${isAppPermissionIssue ? '"Code Infra" app doesn\'t' : "You don't"} seem to have sufficient permissions to perform this action. ${isAppPermissionIssue ? 'Contact' : 'If this seems incorrect, contact'} the infra team regarding the app permissions.${err.response.data.documentation_url ? ` See ${err.response.data.documentation_url} for more information.` : ''}.
${manualTriggerUrl}`,
      );
      return;
    }
    console.error(`❌🔥 Error while invoking the publish workflow.\n. ${manualTriggerUrl}`);
    throw error;
  }
}

/**
 * @param {import('@octokit/rest').Octokit} octokit
 * @param {{owner: string; repo: string}} repoInfo
 * @returns {Promise<string | undefined>}
 */
async function determineGitSha(octokit, repoInfo) {
  console.log(`🔍 Determining the git SHA to use for the release...`);
  // Avoid the deprecation warning when calling octokit.search.issuesAndPullRequests
  // It has been deprecated but new method is not available in @octokit/rest yet.
  octokit.log.warn = () => {};
  const pulls = (
    await octokit.search.issuesAndPullRequests({
      advanced_search: 'true',
      q: `is:pr is:merged label:release repo:${repoInfo.owner}/${repoInfo.repo}`,
      per_page: 1,
    })
  ).data.items;
  if (!pulls.length) {
    console.log(`❌🚨 Could not find any merged release PRs in the repository.`);
    return undefined;
  }

  console.log(
    `🫆  Found the latest merged release PR: ${chalk.bold(pulls[0].title)} (${pulls[0].html_url})`,
  );

  const commits = (
    await octokit.search.commits({
      q: `repo:${repoInfo.owner}/${repoInfo.repo} author:${pulls[0].user?.login} [release]`,
      per_page: 100,
    })
  ).data.items;

  if (!commits.length) {
    console.error(
      `❌🚨 Could not find any commits associated with the release PR: ${pulls[0].html_url}`,
    );
    return undefined;
  }
  const relevantData = commits.map((commit) => ({
    value: commit.sha,
    name: `(${commit.sha.slice(0, 7)}) ${commit.commit.message.split('\n')[0]} by ${commit.author?.login ?? 'no author'} on ${new Date(commit.commit.committer?.date ?? '').toISOString()}`,
    desciption: commit.commit.message,
  }));

  const result = await select({
    message: 'Select the commit to release from:',
    choices: relevantData,
    default: relevantData[0].value,
    pageSize: 10,
  });
  return result;
}
