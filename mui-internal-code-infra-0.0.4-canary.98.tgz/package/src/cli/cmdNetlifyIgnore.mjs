#!/usr/bin/env node

/* eslint-disable no-console */

/**
 * @typedef {Object} Args
 * @property {string[]} workspaces - List of workspace names to process
 * @property {boolean} [check] - Check mode - error if the generated content differs from current
 * @property {string} [baseBranch] - Branch to compare PRs against (default: master)
 */

import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { findWorkspaceDir } from '@pnpm/find-workspace-dir';
import { toPosixPath } from '../utils/path.mjs';
import { getTransitiveDependencies, getWorkspacePackages } from '../utils/pnpm.mjs';

/**
 * Generate the ignore command string for netlify.toml.
 *
 * Production and branch deploys (every Netlify $CONTEXT other than
 * "deploy-preview") always build, so downstream plugins (e.g. e2e triggers)
 * run on every deploy and catch regressions in external dependencies even
 * when the commit doesn't touch the watched paths.
 *
 * Only deploy-previews (PR previews) are eligible to be skipped: they diff
 * against the merge-base with origin/<baseBranch>. This way a PR rebase whose
 * head commit doesn't touch the watched paths still rebuilds when the PR as a
 * whole introduces changes to them — otherwise downstream plugins silently
 * never run.
 *
 * @param {string[]} paths - Array of paths to include in the ignore command
 * @param {string} packagePath - Absolute path to the package directory
 * @param {string} workspaceRoot - Absolute path to the workspace root
 * @param {string} baseBranch - Branch to compare PRs against
 * @returns {string} The ignore command string
 */
function generateIgnoreCommand(paths, packagePath, workspaceRoot, baseBranch) {
  const relFromBase = `${toPosixPath(path.relative(packagePath, workspaceRoot))}/`;
  const pathsStr = paths.join(' ');
  return `  ignore = """cd ${relFromBase} && [ "$CONTEXT" = "deploy-preview" ] && git fetch origin ${baseBranch} --depth=500 -q && git diff --quiet FETCH_HEAD...$COMMIT_REF -- ${pathsStr}"""`;
}

/**
 * Update the netlify.toml file with the new ignore command
 * @param {string} tomlPath - Path to the netlify.toml file
 * @param {string} newIgnoreCommand - The new ignore command to set
 * @param {boolean} checkMode - If true, only check if update is needed
 * @returns {Promise<boolean>} True if file was updated, false otherwise
 */
async function updateNetlifyToml(tomlPath, newIgnoreCommand, checkMode = false) {
  // Read the netlify.toml file
  let tomlContent;
  try {
    tomlContent = await fs.readFile(tomlPath, 'utf8');
  } catch (/** @type {any} */ error) {
    if (error && error.code === 'ENOENT') {
      throw new Error(
        `netlify.toml not found at ${tomlPath}. Ensure this workspace has a netlify.toml file before running this command.`,
      );
    }
    throw error;
  }

  // Replace the ignore line with our new command
  let didReplace = false;
  const updatedContent = tomlContent.replace(/^\s*ignore\s*=.*$/m, () => {
    didReplace = true;
    return newIgnoreCommand;
  });

  if (!didReplace) {
    throw new Error(
      `No ignore line found in ${tomlPath}. Please add an ignore line before running this command.`,
    );
  }

  // Check if content changed
  const hasChanges = tomlContent !== updatedContent;

  if (hasChanges) {
    if (checkMode) {
      throw new Error(`netlify.toml at ${tomlPath} needs updating. Run without --check to update.`);
    }
    await fs.writeFile(tomlPath, updatedContent, 'utf8');
    console.log(`Updated netlify.toml at ${tomlPath}`);
    return true;
  }

  console.log(`netlify.toml at ${tomlPath} is already up to date.`);
  return false;
}

export default /** @type {import('yargs').CommandModule<{}, Args>} */ ({
  command: 'netlify-ignore <workspaces...>',
  describe:
    'Update netlify.toml ignore property with transitive workspace dependencies for the specified workspaces',
  builder: (yargs) => {
    return yargs
      .positional('workspaces', {
        type: 'string',
        array: true,
        describe: 'List of workspace names to process',
        demandOption: true,
      })
      .option('check', {
        type: 'boolean',
        default: false,
        describe: 'Check if the netlify.toml needs updating without modifying it',
      })
      .option('base-branch', {
        type: 'string',
        default: 'master',
        describe:
          "Branch to compare PRs against (the site's production branch on Netlify). Production and branch deploys always rebuild regardless of this value.",
      })
      .example('$0 netlify-ignore @mui/internal-docs-infra', 'Update netlify.toml for a workspace')
      .example(
        '$0 netlify-ignore @mui/internal-docs-infra @mui/internal-code-infra',
        'Update netlify.toml for multiple workspaces',
      )
      .example(
        '$0 netlify-ignore @mui/internal-docs-infra --check',
        'Check if netlify.toml needs updating',
      );
  },
  handler: async (argv) => {
    const { workspaces, check = false, baseBranch = 'master' } = argv;

    // Get the workspace root
    const workspaceRoot = await findWorkspaceDir(process.cwd());
    if (!workspaceRoot) {
      throw new Error('Could not find workspace root directory');
    }

    // Get all workspace packages and create workspace map
    const allWorkspaces = await getWorkspacePackages({ cwd: workspaceRoot });
    const workspaceMap = new Map(
      allWorkspaces.flatMap((workspace) =>
        workspace.name ? [[workspace.name, workspace.path]] : [],
      ),
    );

    // Process each workspace concurrently
    await Promise.all(
      workspaces.map(async (workspaceName) => {
        const workspacePath = workspaceMap.get(workspaceName);
        if (!workspacePath) {
          throw new Error(`Workspace "${workspaceName}" not found`);
        }

        const tomlPath = path.join(workspacePath, 'netlify.toml');

        console.log(`Processing ${workspaceName}...`);

        // Get transitive dependencies for this specific workspace
        const dependencyNames = await getTransitiveDependencies([workspaceName], {
          workspacePathByName: workspaceMap,
        });

        // Convert package names to relative paths (normalize to POSIX separators for git)
        const relativePaths = Array.from(dependencyNames)
          .map((packageName) => {
            const packagePath = workspaceMap.get(packageName);
            if (!packagePath) {
              return null;
            }
            const relativePath = path.relative(workspaceRoot, packagePath);
            // Normalize to POSIX separators for git and cross-platform compatibility
            const posixPath = toPosixPath(relativePath);
            return posixPath && !posixPath.startsWith('..') ? posixPath : null;
          })
          .filter((p) => p !== null)
          .sort();

        // Add pnpm-lock.yaml to the paths
        const allPaths = [...relativePaths, 'pnpm-lock.yaml'];

        // Generate the ignore command for this workspace
        const newIgnoreCommand = generateIgnoreCommand(
          allPaths,
          workspacePath,
          workspaceRoot,
          baseBranch,
        );

        // Update or check the netlify.toml file
        await updateNetlifyToml(tomlPath, newIgnoreCommand, check);
      }),
    );
  },
});
