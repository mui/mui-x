/* eslint-disable no-console */
import { execaCommand } from 'execa';
import timers from 'node:timers/promises';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';
import chalk from 'chalk';
import { Transform } from 'node:stream';
import { Worker } from 'node:worker_threads';

const DEFAULT_CONCURRENCY = 4;
const SERVER_START_TIMEOUT = 10000;

const crawlWorkerUrl = new URL('./crawlWorker.mjs', import.meta.url);

/**
 * Creates a Transform stream that prefixes each line with a given string.
 * Useful for distinguishing server logs from other output.
 * @param {string} prefix - String to prepend to each line
 * @returns {Transform} Transform stream that adds the prefix to each line
 */
const prefixLines = (prefix) => {
  let leftover = '';
  return new Transform({
    transform(chunk, enc, cb) {
      const lines = (leftover + chunk.toString()).split(/\r?\n/);
      leftover = /** @type {string} */ (lines.pop());
      this.push(lines.map((l) => `${prefix + l}\n`).join(''));
      cb();
    },
    flush(cb) {
      if (leftover) {
        this.push(`${prefix + leftover}\n`);
      }
      cb();
    },
  });
};

/**
 * Maps page URLs to sets of known target IDs (anchors) on that page.
 * Used to track which link targets (e.g., #section-id) exist on each page.
 * @typedef {Map<string, Set<string>>} LinkStructure
 */

/**
 * Serialized representation of LinkStructure for JSON storage.
 * Converts Maps and Sets to plain objects and arrays for file persistence.
 * @typedef {Object} SerializedLinkStructure
 * @property {Record<string, string[]>} targets - Object mapping page URLs to arrays of target IDs
 */

/**
 * Fetches a URL and throws an error if the response is not OK.
 * @param {string | URL} url - URL to fetch
 * @returns {Promise<Response>} Fetch response if successful
 * @throws {Error} If the response status is not OK (not in 200-299 range)
 */
async function fetchUrl(url) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Failed to fetch ${url}: [${res.status}] ${res.statusText}`);
  }
  return res;
}

/**
 * Polls a URL until it responds successfully or times out.
 * Used to wait for a dev server to start.
 * @param {string} url - URL to poll
 * @param {number} timeout - Maximum milliseconds to wait before timing out
 * @returns {Promise<void>} Resolves when URL responds successfully
 * @throws {Error} If timeout is reached before URL responds
 */
async function pollUrl(url, timeout) {
  const start = Date.now();
  while (true) {
    try {
      // eslint-disable-next-line no-await-in-loop
      await fetchUrl(url);
      return;
    } catch (/** @type {any} */ error) {
      if (Date.now() - start > timeout) {
        throw new Error(`Timeout waiting for ${url}: ${error.message}`, { cause: error });
      }
      // eslint-disable-next-line no-await-in-loop
      await timers.setTimeout(1000);
    }
  }
}

/**
 * Converts serialized link structure (from JSON) back to Map/Set form.
 * @param {SerializedLinkStructure} data - Serialized structure with plain objects/arrays
 * @returns {LinkStructure} Deserialized structure using Map and Set
 */
function deserializeLinkStructure(data) {
  const linkStructure = new Map();
  for (const url of Object.keys(data.targets)) {
    linkStructure.set(url, new Set(data.targets[url]));
  }
  return linkStructure;
}

/**
 * Input data passed to the crawl worker via workerData.
 * @typedef {Object} CrawlWorkerInput
 * @property {string} pageUrl - The page URL to crawl
 * @property {ResolvedCrawlOptions} options - Fully resolved crawl options
 */

/**
 * Serialized page data returned by the crawl worker (uses arrays instead of Sets for structured clone).
 * @typedef {Object} CrawlWorkerPageData
 * @property {string} url - The normalized page URL
 * @property {number} status - HTTP status code
 * @property {string[]} targets - Array of anchor targets (e.g., '#intro')
 * @property {string} contentType - Content-type of the page
 */

/**
 * Output message posted by the crawl worker.
 * @typedef {Object} CrawlWorkerOutput
 * @property {CrawlWorkerPageData} pageData - Serialized page data
 * @property {Link[]} links - Links discovered on the page
 * @property {{ pageUrl: string, results: import('html-validate').Result[] } | null} htmlValidateResults - HTML validation results, or null if validation was skipped/passed
 */

/**
 * Data about a crawled page including its URL, HTTP status, and available link targets.
 * @typedef {Object} PageData
 * @property {string} url - The normalized page URL (without trailing slash unless root)
 * @property {number} status - HTTP status code from the response (e.g., 200, 404, 500)
 * @property {Set<string>} targets - Set of available anchor targets on the page, keyed by hash (e.g., '#intro')
 * @property {string} contentType - Content-type of the page (e.g., 'text/html', 'text/markdown')
 */

/**
 * Serializes and writes discovered page targets to a JSON file.
 * @param {Map<string, PageData>} pages - Map of crawled pages with their targets
 * @param {string} outPath - File path to write the JSON output
 * @returns {Promise<void>}
 */
async function writePagesToFile(pages, outPath) {
  /** @type {SerializedLinkStructure} */
  const fileContent = { targets: {} };
  for (const [url, pageData] of pages.entries()) {
    fileContent.targets[url] = Array.from(pageData.targets.keys());
  }
  const dir = path.dirname(outPath);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(outPath, JSON.stringify(fileContent, null, 2), 'utf-8');
}

/**
 * Generic concurrent task queue with configurable concurrency limit.
 * Processes tasks in FIFO order with a maximum number of concurrent workers.
 * @template T
 */
class Queue {
  /** Array of pending tasks waiting to be processed */
  /** @type {T[]} */
  tasks = [];

  /** Set of currently running task promises */
  /** @type {Set<Promise<void>>} */
  pending = new Set();

  /**
   * Creates a new queue with a worker function and concurrency limit.
   * @param {(task: T) => Promise<void>} worker - Async function to process each task
   * @param {number} concurrency - Maximum number of tasks to run simultaneously
   */
  constructor(worker, concurrency) {
    this.worker = worker;
    this.concurrency = concurrency;
  }

  /**
   * Adds a task to the queue and starts processing if under concurrency limit.
   * @param {T} task - Task to add to the queue
   */
  add(task) {
    this.tasks.push(task);
    this.run();
  }

  async run() {
    while (this.pending.size < this.concurrency && this.tasks.length > 0) {
      const task = /** @type {T} */ (this.tasks.shift());
      const p = this.worker(task).finally(() => {
        this.pending.delete(p);
        this.run();
      });
      this.pending.add(p);
    }
  }

  /**
   * Waits for all pending and queued tasks to complete.
   * @returns {Promise<void>}
   */
  async waitAll() {
    while (this.pending.size > 0) {
      // eslint-disable-next-line no-await-in-loop
      await Promise.all(this.pending);
    }
  }
}

/**
 * Represents a hyperlink found during crawling.
 * @typedef {Object} Link
 * @property {string | null} src - URL of the page where this link was found, or null for seed URLs
 * @property {string | null} text - Accessible name/text content of the link element, or null for seed URLs
 * @property {string} href - The href attribute value (may be relative or absolute, with or without hash)
 * @property {string | null} [contentType] - Content-type of the source page (e.g., 'text/html', 'text/markdown')
 */

/**
 * Rule for ignoring broken links. All properties are optional but at least one must be defined.
 * Properties use OR logic internally (any pattern can match), AND logic between properties (all specified must match).
 * @typedef {Object} IgnoreRule
 * @property {(string | RegExp) | (string | RegExp)[]} [path] - Pattern(s) to match source page path
 * @property {(string | RegExp) | (string | RegExp)[]} [href] - Pattern(s) to match broken link href
 * @property {(string | RegExp) | (string | RegExp)[]} [contentType] - Pattern(s) to match source page content-type
 */

/**
 * Normalized ignore rule where all properties are arrays (or undefined).
 * @typedef {Object} NormalizedIgnoreRule
 * @property {(string | RegExp)[] | undefined} path
 * @property {(string | RegExp)[] | undefined} href
 * @property {(string | RegExp)[] | undefined} contentType
 */

/**
 * Extracts and normalizes the page URL from a link.
 * Returns null for external links, ignored paths, or non-standard URLs.
 * Normalizes by removing trailing slashes (except root) and preserving query params.
 * Resolves relative links against the source URL.
 * @param {Link} link - Link object containing href and source URL
 * @param {RegExp[]} ignoredPaths - Array of patterns to exclude
 * @returns {string | null} Normalized page URL with query but without hash, or null if external/ignored
 */
function getPageUrl(link, ignoredPaths = []) {
  // Skip external URLs (http://, https://, mailto:, tel:, etc.)
  if (/^[a-z][a-z0-9+.-]*:/i.test(link.href)) {
    return null;
  }

  // Resolve relative links against source URL
  const baseUrl = link.src ? `http://localhost${link.src}` : 'http://localhost/';
  const parsed = new URL(link.href, baseUrl);

  if (ignoredPaths.some((pattern) => pattern.test(parsed.pathname))) {
    return null;
  }
  // Normalize pathname by removing trailing slash (except for root)
  let pathname = parsed.pathname;
  if (pathname !== '/' && pathname.endsWith('/')) {
    pathname = pathname.slice(0, -1);
  }
  const pageUrl = pathname + parsed.search;
  return pageUrl;
}

/**
 * Tests if a value matches a pattern.
 * @param {string} value - The value to test
 * @param {string | RegExp} pattern - The pattern to match against. Strings use exact match.
 * @returns {boolean}
 */
function matchesPattern(value, pattern) {
  if (typeof pattern === 'string') {
    return value === pattern;
  }
  return pattern.test(value);
}

/**
 * Tests if a value matches any of the patterns in the array.
 * Returns true if patterns is undefined/empty (wildcard behavior).
 * @param {string} value - The value to test
 * @param {(string | RegExp)[] | undefined} patterns - Array of patterns (OR logic)
 * @returns {boolean}
 */
function matchesAnyPattern(value, patterns) {
  if (!patterns || patterns.length === 0) {
    return true; // No patterns = matches any
  }
  return patterns.some((pattern) => matchesPattern(value, pattern));
}

/**
 * Normalizes a value to an array. Returns undefined if value is undefined.
 * @template T
 * @param {T | T[] | undefined} value
 * @returns {T[] | undefined}
 */
function normalizeToArray(value) {
  if (value === undefined) {
    return undefined;
  }
  return Array.isArray(value) ? value : [value];
}

/**
 * Normalizes an ignore rule by converting all properties to arrays.
 * @param {IgnoreRule} rule
 * @returns {NormalizedIgnoreRule}
 */
function normalizeIgnoreRule(rule) {
  return {
    path: normalizeToArray(rule.path),
    href: normalizeToArray(rule.href),
    contentType: normalizeToArray(rule.contentType),
  };
}

/**
 * Checks if a link should be ignored based on configured ignore patterns.
 * @param {Link} link - The link to check (includes src, href, contentType)
 * @param {NormalizedIgnoreRule[]} ignores - Normalized ignore rules
 * @returns {boolean}
 */
function shouldIgnoreLink(link, ignores) {
  return ignores.some((rule) => {
    // Path matching (OR within patterns, wildcard if undefined)
    const pathMatches = matchesAnyPattern(link.src ?? '', rule.path);
    // Href matching
    const hrefMatches = matchesAnyPattern(link.href, rule.href);
    // Content-type matching
    const contentTypeMatches = matchesAnyPattern(link.contentType ?? '', rule.contentType);

    // AND logic between properties
    return pathMatches && hrefMatches && contentTypeMatches;
  });
}

/**
 * Configuration options for the broken links crawler.
 * @typedef {Object} CrawlOptions
 * @property {string | null} [startCommand] - Shell command to start the dev server (e.g., 'npm run dev'). If null, assumes server is already running
 * @property {string} host - Base URL of the site to crawl (e.g., 'http://localhost:3000')
 * @property {string | null} [outPath] - File path to write discovered link targets to. If null, targets are not persisted
 * @property {RegExp[]} [ignoredPaths] - Array of regex patterns to exclude from crawling (e.g., [/^\/api\//] to skip /api/* routes)
 * @property {string[]} [ignoredContent] - CSS selectors for elements whose nested links should be ignored (e.g., ['.sidebar', 'footer'])
 * @property {Set<string>} [ignoredTargets] - Set of element IDs to ignore as link targets (defaults to '__next', '__NEXT_DATA__')
 * @property {Map<string, Set<string>>} [knownTargets] - Pre-populated map of known valid targets to skip crawling (useful for external pages)
 * @property {string[]} [knownTargetsDownloadUrl] - URLs to fetch known targets from (fetched JSON will be merged with knownTargets)
 * @property {number} [concurrency] - Number of concurrent page fetches (defaults to 4)
 * @property {string[]} [seedUrls] - Starting URLs for the crawl (defaults to ['/'])
 * @property {IgnoreRule[]} [ignores] - Rules to ignore broken links. Each rule can have path, href, contentType, and/or has properties. All specified properties must match (AND logic). Within a property, multiple values use OR logic.
 * @property {HtmlValidateOption} [htmlValidate] - Enable HTML validation on crawled pages. `false` (default): disabled. `true`: validate with recommended rules. Object: use as html-validate config — `mui:recommended` is always applied as the baseline, so most callers only need to set `rules`. Array: per-path config overrides — `mui:recommended` is applied once as the baseline and every entry whose `path` matches the page URL is layered on top; later matching entries win on conflicting rule keys. If an entry omits `extends`, it behaves like a rule patch and typically only changes the rules it names. If an entry includes `extends` (for example, re-extending `mui:recommended`), it can re-introduce or reset baseline presets rather than acting as a pure patch. An entry without `path` matches every page. If no entry matches, the page is not validated.
 * @property {boolean} [verbose] - Log extra diagnostics during crawling (e.g. resolved html-validate config per page). Defaults to `false`.
 */

/**
 * Per-page HTML validation override entry.
 * @typedef {Object} HtmlValidateOverride
 * @property {(string | RegExp) | (string | RegExp)[]} [path] - Pattern(s) to match the page URL. Strings use exact match. Omit to match every page.
 * @property {true | import('html-validate').ConfigData} config - html-validate config (or `true` for `mui:recommended`).
 */

/**
 * Public shape of the htmlValidate option.
 * @typedef {boolean | import('html-validate').ConfigData | HtmlValidateOverride[]} HtmlValidateOption
 */

/**
 * Resolved per-page HTML validation entry. Empty array means validation is disabled.
 * @typedef {{ path: (string | RegExp)[] | undefined, config: import('html-validate').ConfigData }} ResolvedHtmlValidateEntry
 */

/**
 * Fully resolved configuration with all optional fields filled with defaults.
 * @typedef {Omit<Required<CrawlOptions>, 'ignores' | 'htmlValidate'> & { ignores: NormalizedIgnoreRule[], htmlValidate: ResolvedHtmlValidateEntry[] }} ResolvedCrawlOptions
 */

/**
 * Validates that an ignore rule has at least one property defined.
 * @param {IgnoreRule} rule
 * @throws {Error} If no property is defined
 */
function validateIgnoreRule(rule) {
  if (!rule.path && !rule.href && !rule.contentType) {
    throw new Error(
      'Each ignore rule must have at least one property defined (path, href, or contentType)',
    );
  }
}

/**
 * Normalizes a single config value to a non-null html-validate config object.
 * Each config is registered as a pure rule patch; `mui:recommended` is pulled
 * in once by the page's root config (ahead of every patch), so callers only
 * need to specify the `rules` they want to change and never restate the
 * recommended ruleset. `true` means "recommended only" (an empty patch). An
 * explicit `extends` is still honored if a caller wants extra presets.
 * @param {true | import('html-validate').ConfigData} config
 * @returns {import('html-validate').ConfigData}
 */
function normalizeHtmlValidateConfig(config) {
  if (config === true) {
    return {};
  }
  return config;
}

/**
 * Resolves the htmlValidate option into an array of per-page entries.
 * An empty array means validation is disabled.
 * @param {HtmlValidateOption | undefined} option
 * @returns {ResolvedHtmlValidateEntry[]}
 */
function resolveHtmlValidateConfig(option) {
  if (!option) {
    return [];
  }
  if (option === true || !Array.isArray(option)) {
    return [{ path: undefined, config: normalizeHtmlValidateConfig(option) }];
  }
  return option.map((entry) => ({
    path: normalizeToArray(entry.path),
    config: normalizeHtmlValidateConfig(entry.config),
  }));
}

/**
 * Resolves partial crawl options by filling in defaults for all optional fields.
 * @param {CrawlOptions} rawOptions - Partial options from user
 * @returns {ResolvedCrawlOptions} Fully resolved options with all defaults applied
 */
function resolveOptions(rawOptions) {
  const rawIgnores = rawOptions.ignores ?? [];
  // Validate and normalize ignore rules
  for (const rule of rawIgnores) {
    validateIgnoreRule(rule);
  }
  const normalizedIgnores = rawIgnores.map(normalizeIgnoreRule);

  return {
    startCommand: rawOptions.startCommand ?? null,
    host: rawOptions.host,
    outPath: rawOptions.outPath ?? null,
    ignoredPaths: rawOptions.ignoredPaths ?? [],
    ignoredContent: rawOptions.ignoredContent ?? [],
    ignoredTargets: rawOptions.ignoredTargets ?? new Set(['__next', '__NEXT_DATA__']),
    knownTargets: rawOptions.knownTargets ?? new Map(),
    knownTargetsDownloadUrl: rawOptions.knownTargetsDownloadUrl ?? [],
    concurrency: rawOptions.concurrency ?? DEFAULT_CONCURRENCY,
    seedUrls: rawOptions.seedUrls ?? ['/'],
    ignores: normalizedIgnores,
    htmlValidate: resolveHtmlValidateConfig(rawOptions.htmlValidate),
    verbose: rawOptions.verbose ?? false,
  };
}

/**
 * Merges multiple Maps, similar to Object.assign for objects.
 * Later sources override earlier ones for duplicate keys.
 * @template K, V
 * @param {Map<K, V>} target - Target map to merge into (will be mutated)
 * @param {...Map<K, V>} sources - Source maps to merge from
 * @returns {Map<K, V>} The mutated target map
 */
function mergeMaps(target, ...sources) {
  for (const source of sources) {
    for (const [key, value] of source.entries()) {
      target.set(key, value);
    }
  }
  return target;
}

/**
 * Downloads and deserializes known link targets from remote URLs.
 * Fetches JSON files containing serialized link structures in parallel.
 * @param {string[]} urls - Array of URLs to fetch known targets from
 * @returns {Promise<LinkStructure[]>} Array of deserialized link structures
 */
async function downloadKnownTargets(urls) {
  if (urls.length === 0) {
    return [];
  }

  console.log(chalk.blue(`Downloading known targets from ${urls.length} URL(s)...`));

  const results = await Promise.all(
    urls.map(async (url) => {
      console.log(`  Fetching ${chalk.underline(url)}`);
      const res = await fetchUrl(url);
      const data = await res.json();
      return deserializeLinkStructure(data);
    }),
  );

  return results;
}

/**
 * Resolves all known targets by downloading remote ones and merging with user-provided.
 * User-provided targets take priority over downloaded ones.
 * @param {ResolvedCrawlOptions} options - Resolved crawl options
 * @returns {Promise<LinkStructure>} Merged map of all known targets
 */
async function resolveKnownTargets(options) {
  const downloaded = await downloadKnownTargets(options.knownTargetsDownloadUrl);
  // Merge downloaded with user-provided, user-provided takes priority
  return mergeMaps(new Map(), ...downloaded, options.knownTargets);
}

/**
 * Represents a broken link or broken link target discovered during crawling.
 * @typedef {Object} BrokenLinkIssue
 * @property {'broken-link' | 'broken-target'} type - Type of issue: 'broken-link' for 404 pages, 'broken-target' for missing anchors
 * @property {string} message - Human-readable description of the issue (e.g., 'Target not found', 'Page returned error 404')
 * @property {Link} link - The link object that has the issue
 */

/**
 * Represents an HTML validation issue found on a crawled page.
 * @typedef {Object} HtmlValidateIssue
 * @property {'html-validate'} type - Issue type discriminator
 * @property {string} message - Human-readable description of the issue
 * @property {string} pageUrl - The page URL where the issue was found
 * @property {string} ruleId - The html-validate rule that triggered this issue (e.g., 'no-dup-id')
 * @property {number} severity - Severity level (1 = warning, 2 = error)
 * @property {{ line: number, column: number }} location - Source location of the issue
 * @property {string | null} selector - DOM selector for the element, or null
 */

/**
 * Any issue discovered during crawling.
 * @typedef {BrokenLinkIssue | HtmlValidateIssue} Issue
 */

/**
 * Results from a complete crawl operation.
 * @typedef {Object} CrawlResult
 * @property {Set<Link>} links - All links discovered during the crawl
 * @property {Map<string, PageData>} pages - All pages crawled, keyed by normalized URL
 * @property {Issue[]} issues - All issues found (broken links, broken targets, and HTML validation issues)
 */

/**
 * Reports broken links to stderr, grouped by source page for better readability.
 * @param {BrokenLinkIssue[]} issuesList - Array of broken link issues to report
 */
function reportBrokenLinks(issuesList) {
  if (issuesList.length === 0) {
    return;
  }

  console.error('\nBroken links found:\n');

  // Group issues by source URL
  /** @type {Map<string, BrokenLinkIssue[]>} */
  const issuesBySource = new Map();
  for (const issue of issuesList) {
    const sourceUrl = issue.link.src ?? '(unknown)';
    const sourceIssues = issuesBySource.get(sourceUrl) ?? [];
    if (sourceIssues.length === 0) {
      issuesBySource.set(sourceUrl, sourceIssues);
    }
    sourceIssues.push(issue);
  }

  // Report issues grouped by source
  for (const [sourceUrl, sourceIssues] of issuesBySource.entries()) {
    console.error(`Source ${chalk.cyan(sourceUrl)}:`);
    for (const issue of sourceIssues) {
      const reason = issue.type === 'broken-target' ? 'target not found' : 'returned status 404';
      console.error(`  [${issue.link.text}](${chalk.cyan(issue.link.href)}) (${reason})`);
    }
  }
}

/**
 * Reports HTML validation issues to stderr, grouped by page URL.
 * @param {HtmlValidateIssue[]} htmlIssues - Array of HTML validation issues to report
 */
function reportHtmlValidation(htmlIssues) {
  if (htmlIssues.length === 0) {
    return;
  }

  console.error('\nHTML validation issues:\n');

  // Group by page URL
  /** @type {Map<string, HtmlValidateIssue[]>} */
  const issuesByPage = new Map();
  for (const issue of htmlIssues) {
    const pageIssues = issuesByPage.get(issue.pageUrl) ?? [];
    if (pageIssues.length === 0) {
      issuesByPage.set(issue.pageUrl, pageIssues);
    }
    pageIssues.push(issue);
  }

  for (const [pageUrl, pageIssues] of issuesByPage.entries()) {
    console.error(`Page ${chalk.cyan(pageUrl)}:`);
    for (const issue of pageIssues) {
      const severityLabel = issue.severity === 2 ? chalk.red('error') : chalk.yellow('warning');
      console.error(
        `  ${issue.location.line}:${issue.location.column}  ${severityLabel}  ${issue.message}  ${chalk.gray(issue.ruleId)}`,
      );
    }
  }
}

/**
 * Crawls a website starting from seed URLs, discovering all internal links and checking for broken links/targets.
 * @param {CrawlOptions} rawOptions - Configuration options for the crawl
 * @returns {Promise<CrawlResult>} Crawl results including all links, pages, and issues found
 */
export async function crawl(rawOptions) {
  const options = resolveOptions(rawOptions);
  const startTime = Date.now();

  /** @type {AbortController | null} */
  let controller = null;

  try {
    if (options.startCommand) {
      console.log(chalk.blue(`Starting server with "${options.startCommand}"...`));
      controller = new AbortController();
      const appProcess = execaCommand(options.startCommand, {
        stdout: 'pipe',
        stderr: 'pipe',
        cancelSignal: controller.signal,
        env: {
          FORCE_COLOR: '1',
          ...process.env,
        },
      });

      // Prefix server logs
      const serverPrefix = chalk.gray('server: ');
      appProcess.stdout.pipe(prefixLines(serverPrefix)).pipe(process.stdout);
      appProcess.stderr.pipe(prefixLines(serverPrefix)).pipe(process.stderr);
      appProcess.catch(() => {});

      // Poll the first page we are about to crawl (resolved against host) so we
      // wait for the actual entry point to be serveable rather than the
      // homepage, which may be a different (slower) page.
      const healthcheckUrl = new URL(options.seedUrls[0] ?? '/', options.host).href;
      await pollUrl(healthcheckUrl, SERVER_START_TIMEOUT);

      console.log(`Server started on ${chalk.underline(options.host)}`);
    }

    return await runCrawl(options, startTime);
  } finally {
    // Always stop the server, even when startup or crawling throws. Without
    // this, a failed healthcheck (or any error) would leave the dev server
    // running, which on slow environments (e.g. Netlify) leads to orphaned
    // servers piling up across retries.
    if (controller) {
      console.log(chalk.blue('Stopping server...'));
      controller.abort();
    }
  }
}

/**
 * Runs the crawl against an already-running server.
 * @param {ResolvedCrawlOptions} options - Fully resolved crawl options
 * @param {number} startTime - Timestamp (ms) when the crawl began, for duration reporting
 * @returns {Promise<CrawlResult>} Crawl results including all links, pages, and issues found
 */
async function runCrawl(options, startTime) {
  const knownTargets = await resolveKnownTargets(options);

  /** @type {Map<string, Promise<PageData>>} */
  const crawledPages = new Map();
  /** @type {Set<Link>} */
  const crawledLinks = new Set();
  /** @type {Issue[]} */
  const issues = [];
  /**
   * Spawns a crawl worker for a page URL.
   * @param {string} pageUrl - The page URL to crawl
   * @returns {Promise<{ pageData: PageData, links: Link[], htmlValidateResults: CrawlWorkerOutput['htmlValidateResults'] }>}
   */
  function crawlInWorker(pageUrl) {
    return new Promise((resolve, reject) => {
      /** @type {CrawlWorkerInput} */
      const input = { pageUrl, options };
      const worker = new Worker(crawlWorkerUrl, {
        workerData: input,
      });
      worker.on('message', (/** @type {CrawlWorkerOutput} */ msg) => {
        resolve({
          pageData: {
            url: msg.pageData.url,
            status: msg.pageData.status,
            targets: new Set(msg.pageData.targets),
            contentType: msg.pageData.contentType,
          },
          links: msg.links,
          htmlValidateResults: msg.htmlValidateResults,
        });
      });
      worker.on('error', (err) => reject(err));
    });
  }

  const queue = new Queue(async (/** @type {Link} */ link) => {
    crawledLinks.add(link);

    const pageUrl = getPageUrl(link, options.ignoredPaths);
    if (pageUrl === null) {
      return;
    }

    if (knownTargets.has(pageUrl)) {
      return;
    }

    if (crawledPages.has(pageUrl)) {
      return;
    }

    console.log(`Crawling ${chalk.cyan(pageUrl)}...`);
    const workerPromise = crawlInWorker(pageUrl);
    const pagePromise = workerPromise.then((result) => {
      if (result.htmlValidateResults) {
        for (const validationResult of result.htmlValidateResults.results) {
          for (const msg of validationResult.messages) {
            issues.push({
              type: 'html-validate',
              message: msg.message,
              pageUrl: result.htmlValidateResults.pageUrl,
              ruleId: msg.ruleId,
              severity: msg.severity,
              location: { line: msg.line, column: msg.column },
              selector: msg.selector,
            });
          }
        }
      }

      for (const discoveredLink of result.links) {
        queue.add(discoveredLink);
      }

      return result.pageData;
    });

    crawledPages.set(pageUrl, pagePromise);

    await pagePromise;
  }, options.concurrency);

  for (const seedUrl of options.seedUrls) {
    queue.add({ src: null, text: null, href: seedUrl });
  }

  await queue.waitAll();

  const results = new Map(
    await Promise.all(
      Array.from(crawledPages.entries(), async ([a, b]) => /** @type {const} */ ([a, await b])),
    ),
  );

  if (options.outPath) {
    await writePagesToFile(results, options.outPath);
  }

  /** Count of links ignored due to ignores configuration */
  let ignoredCount = 0;

  /**
   * Records a broken link or target issue.
   * @param {Link} link - The link with the issue
   * @param {'broken-target' | 'broken-link'} type - Type of issue
   * @param {string} message - Human-readable error message
   */
  function recordBrokenLink(link, type, message) {
    // Check if this link should be ignored
    if (shouldIgnoreLink(link, options.ignores)) {
      ignoredCount += 1;
      console.log(chalk.yellow(`  [ignored] ${link.text} -> ${link.href}`));
      return;
    }

    issues.push({
      type,
      message,
      link,
    });
  }

  for (const crawledLink of crawledLinks) {
    const pageUrl = getPageUrl(crawledLink, options.ignoredPaths);
    if (pageUrl !== null) {
      // Internal link
      const baseUrl = crawledLink.src ? `http://localhost${crawledLink.src}` : 'http://localhost/';
      const parsed = new URL(crawledLink.href, baseUrl);

      const knownPage = knownTargets.get(pageUrl);
      if (knownPage) {
        if (parsed.hash && !knownPage.has(parsed.hash)) {
          recordBrokenLink(crawledLink, 'broken-target', 'Target not found');
        } else {
          // all good
        }
      } else {
        const page = results.get(pageUrl);

        if (!page) {
          recordBrokenLink(crawledLink, 'broken-link', 'Page not crawled');
        } else if (page.status >= 400) {
          recordBrokenLink(crawledLink, 'broken-link', `Page returned error ${page.status}`);
        } else if (parsed.hash) {
          if (!page.targets.has(parsed.hash)) {
            recordBrokenLink(crawledLink, 'broken-target', 'Target not found');
          }
        } else {
          // all good
        }
      }
    }
  }

  // Split issues by type for reporting
  /** @type {BrokenLinkIssue[]} */
  const brokenLinkIssues = /** @type {BrokenLinkIssue[]} */ (
    issues.filter((issue) => issue.type === 'broken-link' || issue.type === 'broken-target')
  );
  /** @type {HtmlValidateIssue[]} */
  const htmlValidateIssues = /** @type {HtmlValidateIssue[]} */ (
    issues.filter((issue) => issue.type === 'html-validate')
  );

  reportBrokenLinks(brokenLinkIssues);
  reportHtmlValidation(htmlValidateIssues);

  // Derive counts from issues
  const brokenLinks = brokenLinkIssues.filter((issue) => issue.type === 'broken-link').length;
  const brokenLinkTargets = brokenLinkIssues.filter(
    (issue) => issue.type === 'broken-target',
  ).length;

  const endTime = Date.now();
  const durationSeconds = (endTime - startTime) / 1000;
  const duration = new Intl.NumberFormat('en-US', {
    style: 'unit',
    unit: 'second',
    maximumFractionDigits: 2,
  }).format(durationSeconds);
  const fmt = new Intl.NumberFormat('en-US').format;
  console.log(chalk.blue(`\nCrawl completed in ${duration}`));
  console.log(`  Total links found: ${chalk.cyan(fmt(crawledLinks.size))}`);
  console.log(`  Total broken links: ${chalk.cyan(fmt(brokenLinks))}`);
  console.log(`  Total broken link targets: ${chalk.cyan(fmt(brokenLinkTargets))}`);
  console.log(`  Total ignored: ${chalk.cyan(fmt(ignoredCount))}`);
  if (options.htmlValidate.length > 0) {
    const pagesWithHtmlIssues = new Set(htmlValidateIssues.map((issue) => issue.pageUrl)).size;
    console.log(
      `  HTML validation issues: ${chalk.cyan(fmt(htmlValidateIssues.length))} across ${chalk.cyan(fmt(pagesWithHtmlIssues))} ${pagesWithHtmlIssues === 1 ? 'page' : 'pages'}`,
    );
  }

  if (options.outPath) {
    console.log(chalk.blue(`Output written to: ${pathToFileURL(options.outPath)}`));
  }

  return { links: crawledLinks, pages: results, issues };
}
